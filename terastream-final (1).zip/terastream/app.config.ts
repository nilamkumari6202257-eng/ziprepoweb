export default { logoUrl: "" };
