import { defineConfig, loadEnv, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';

// Mounts the self-hosted TeraBox API inside `npm run dev` (no separate backend, no Supabase).
function teraboxApi(mode: string): Plugin {
  return {
    name: 'terabox-api',
    async configureServer(server) {
      // expose server-only vars (NDUS_TOKENS, PROXY_SECRET ...) from .env to the handler
      const env = loadEnv(mode, process.cwd(), '');
      for (const [k, v] of Object.entries(env)) if (!(k in process.env)) process.env[k] = v;

      const { API_PATH, handleTerabox } = await import('./server/terabox.mjs');
      const { ADMIN_PATH, handleAdmin } = await import('./server/admin.mjs');
      server.middlewares.use((req, res, next) => {
        const path = (req.url || '').split('?')[0];
        if (path === API_PATH) {
          handleTerabox(req, res);
        } else if (path === ADMIN_PATH) {
          handleAdmin(req, res);
        } else {
          next();
        }
      });
    },
  };
}

export default defineConfig(({ mode }) => ({
  plugins: [react(), teraboxApi(mode)],
  resolve: { alias: { '@': path.resolve(__dirname, './src') } },
  server: { host: '0.0.0.0', port: 5173 },
}));
