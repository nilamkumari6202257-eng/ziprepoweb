export type VideoSourceType = 'terabox' | 'direct' | 'hls' | 'embed';
export type VideoStatus = 'published' | 'draft';
export type AdPosition =
  | 'header_top'
  | 'above_player'
  | 'below_player'
  | 'watch_sidebar'
  | 'catalog_banner'
  | 'related_between'
  | 'native_banner'
  | 'social_bar'
  | 'sticky_bottom'
  | 'popunder_interstitial';

export interface VideoResolutionOption { label: string; url: string; height?: number; }
export type VideoQuality = 'Auto' | '1080P' | '720P' | '480P';
export type PlaybackSpeed = 0.5 | 0.75 | 1 | 1.25 | 1.5 | 2;

export interface VideoItem {
  id: string; title: string; slug: string; description: string; thumbnail: string;
  videoUrl: string; embedUrl?: string; directStreamUrl?: string; sourceType: VideoSourceType;
  teraboxShareId?: string; category: string; tags: string[]; duration: number;
  durationFormatted?: string; views: number; likes: number; dislikes: number;
  featured: boolean; trending: boolean; status: VideoStatus; createdAt: string; updatedAt: string;
  resolutions?: VideoResolutionOption[];
}

export interface CategoryItem { id: string; name: string; slug: string; description?: string; icon?: string; color?: string; }
export interface AdUnit {
  id: string; name: string; position: AdPosition; enabled: boolean; type: 'adsterra' | 'script' | 'html';
  dimensions: string; deviceTarget: 'all' | 'mobile' | 'desktop'; code: string;
  /** Optional separate code for phones (e.g. a 320x50 banner). Used instead of `code` on screens < 768px. */
  mobileCode?: string; notes?: string;
}
export interface SiteSettings {
  siteName: string; tagline: string; logoText: string; logoUrl?: string; announcementText: string;
  showAnnouncement: boolean; announcementLink?: string; defaultMetaDescription: string; defaultKeywords: string;
  footerText: string; telegramUrl?: string; whatsappUrl?: string; twitterUrl?: string; discordUrl?: string;
  adblockNoticeTitle: string; adblockNoticeMessage: string; showAdblockNotice: boolean; contactEmail?: string;
  popunderFrequencyHours?: number; showIntermediatePage?: boolean; intermediateWaitSeconds?: number;
}
export interface VideoComment { id: string; videoId: string; userName: string; userAvatar?: string; content: string; createdAt: string; likes: number; }
export interface UserInteractionState { likedVideos: string[]; dislikedVideos: string[]; emojiReactions: Record<string, string>; watchlist: string[]; history: string[]; }
