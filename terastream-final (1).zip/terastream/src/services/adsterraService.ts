import { storageService } from './storageService';
import { hasRunnableCode, isDirectLink } from './adsConfig';
import type { AdUnit } from '@/types/video';

const CAP_KEY = 'cinemitra_popunder_last_shown_v2';
const DEFAULT_CAP_HOURS = 24;

let firedThisPageLoad = false; // fallback cap if localStorage is blocked (private mode etc.)
const mountedGlobal = new Set<string>();

const readCap = (): number => {
  try {
    return Number(localStorage.getItem(CAP_KEY) || 0) || 0;
  } catch {
    return 0;
  }
};
const writeCap = (): void => {
  firedThisPageLoad = true;
  try {
    localStorage.setItem(CAP_KEY, String(Date.now()));
  } catch {
    /* blocked storage: the in-memory flag above still caps this page load */
  }
};

const isMobileViewport = (): boolean =>
  typeof window !== 'undefined' && typeof window.matchMedia === 'function' && window.matchMedia('(max-width: 767px)').matches;

const deviceAllowed = (ad: AdUnit): boolean =>
  ad.deviceTarget === 'all' || !ad.deviceTarget || (ad.deviceTarget === 'mobile') === isMobileViewport();

/** Recreate <script> tags so the browser really executes them; they load async and never block rendering. */
export function injectAdHtml(code: string, marker: string): void {
  if (!code || typeof document === 'undefined') return;
  const doc = new DOMParser().parseFromString(code, 'text/html');
  const nodes = [...Array.from(doc.head.childNodes), ...Array.from(doc.body.childNodes)];
  for (const node of nodes) {
    if (node.nodeName === 'SCRIPT') {
      const old = node as HTMLScriptElement;
      const script = document.createElement('script');
      Array.from(old.attributes).forEach((a) => script.setAttribute(a.name, a.value));
      if (old.src) script.async = true;
      script.textContent = old.textContent || '';
      script.setAttribute('data-cm-ad', marker);
      document.body.appendChild(script);
    } else if (node.nodeType === 1) {
      const el = document.importNode(node, true) as HTMLElement;
      el.setAttribute('data-cm-ad', marker);
      document.body.appendChild(el);
    }
  }
}

export const adsterraService = {
  getPopunderAd(): AdUnit | null {
    const ad = storageService.getAds().find((a) => a.position === 'popunder_interstitial' && a.enabled);
    if (!ad || !hasRunnableCode(ad.code) || !deviceAllowed(ad)) return null;
    return ad;
  },

  canShowPopunder(): boolean {
    if (firedThisPageLoad) return false;
    if (!this.getPopunderAd()) return false;
    const hours = Number(storageService.getSettings().popunderFrequencyHours) || DEFAULT_CAP_HOURS;
    return Date.now() - readCap() >= hours * 60 * 60 * 1000;
  },

  /** Call from a real user click (the Play button). Returns true if a popunder was started. */
  triggerPopunder(): boolean {
    if (!this.canShowPopunder()) return false;
    const ad = this.getPopunderAd();
    if (!ad) return false;
    writeCap();
    try {
      const code = ad.code.trim();
      if (isDirectLink(code)) {
        // Adsterra Direct Link: open it in a new tab and bring the video tab back to front.
        const w = window.open(code, '_blank', 'noopener');
        if (w) window.focus();
      } else {
        injectAdHtml(code, 'popunder');
      }
    } catch (e) {
      console.warn('Popunder failed', e);
    }
    return true;
  },

  /** Social Bar & other page-level scripts: injected once, async. */
  mountGlobalScript(adId: string, code: string): void {
    const key = `${adId}:${code.length}:${code.slice(0, 60)}`;
    if (mountedGlobal.has(key)) return;
    mountedGlobal.add(key);
    const start = () => injectAdHtml(code, adId);
    const ric = (window as Window & { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => number }).requestIdleCallback;
    if (ric) ric(start, { timeout: 3000 });
    else window.setTimeout(start, 1500);
  },
};
