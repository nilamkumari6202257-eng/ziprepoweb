import {
  VideoItem,
  CategoryItem,
  AdUnit,
  SiteSettings,
  VideoComment,
  UserInteractionState,
} from '@/types/video';
import {
  formatDuration,
  DEFAULT_ADAPTIVE_STREAMS,
  extractTeraboxShareId,
  buildTeraboxEmbedUrl,
} from './teraboxParser';
import { adminApi } from './adminApi';
import { SLOT_CATALOG, isPlaceholderCode } from './adsConfig';
import { toast } from 'sonner';

const DEFAULT_POSTERS = [
  'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1280&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1280&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=1280&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1280&auto=format&fit=crop&q=80',
];

const STORAGE_KEYS = {
  VIDEOS: 'tb_stream_videos_v1',
  CATEGORIES: 'tb_stream_categories_v1',
  ADS: 'tb_stream_ads_v1',
  SETTINGS: 'tb_stream_settings_v1',
  COMMENTS: 'tb_stream_comments_v1',
  INTERACTIONS: 'tb_stream_user_interactions_v1',
  ADMIN_AUTH: 'tb_stream_admin_auth_v1',
};

// Data the admin panel controls. It lives on the server; localStorage is only a cache of it.
// (server key -> local cache key)
const SERVER_SYNCED: Record<string, string> = {
  videos: STORAGE_KEYS.VIDEOS,
  categories: STORAGE_KEYS.CATEGORIES,
  ads: STORAGE_KEYS.ADS,
  settings: STORAGE_KEYS.SETTINGS,
};

export const DEFAULT_CATEGORIES: CategoryItem[] = [
  { id: 'cat-movies', name: 'Movies & Cinema', slug: 'movies', description: 'Blockbuster films, cinema cuts, and trailers', icon: 'Film', color: '#8b5cf6' },
  { id: 'cat-anime', name: 'Anime & Animations', slug: 'anime', description: 'Top rated anime episodes, AMVs, and animated shorts', icon: 'Sparkles', color: '#ec4899' },
  { id: 'cat-series', name: 'TV Series & Dramas', slug: 'series', description: 'Binge-worthy shows, web series, and seasons', icon: 'Tv', color: '#06b6d4' },
  { id: 'cat-tutorials', name: 'Tech & Tutorials', slug: 'tutorials', description: 'Programming guides, design workflows, and AI tools', icon: 'Cpu', color: '#10b981' },
  { id: 'cat-music', name: 'Music & Vibes', slug: 'music', description: 'Music videos, concert cuts, and lo-fi mixes', icon: 'Music', color: '#f59e0b' },
  { id: 'cat-clips', name: 'Viral Clips & Shorts', slug: 'clips', description: 'Trending moments, hilarious reactions, and reels', icon: 'Flame', color: '#ef4444' },
];

export const DEFAULT_VIDEOS: VideoItem[] = [
  {
    id: 'vid-user-test-video',
    title: 'VID_20260903_195703_985 (TeraBox VIP Test)',
    slug: 'vid-20260903-195703-985-terabox-test',
    description: 'User test video stream directly linked from TeraBox: https://1024terabox.com/s/193MmrOLKKnNgpoOloSso4w. Configured with VIP Ndus tokens for instant uninterrupted playback.',
    thumbnail: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1280&auto=format&fit=crop&q=80',
    videoUrl: 'https://1024terabox.com/s/193MmrOLKKnNgpoOloSso4w',
    embedUrl: 'https://www.1024tera.com/sharing/embed?surl=93MmrOLKKnNgpoOloSso4w',
    teraboxShareId: '93MmrOLKKnNgpoOloSso4w',
    sourceType: 'terabox',
    category: 'movies',
    tags: ['TeraBox Test', 'VIP Stream', 'User Video', '1080P', 'Ndus Token'],
    duration: 240,
    durationFormatted: '04:00',
    views: 19800,
    likes: 1850,
    dislikes: 4,
    featured: true,
    trending: true,
    status: 'published',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    resolutions: [
      { label: 'Auto (1080P)', url: 'https://www.1024tera.com/sharing/embed?surl=93MmrOLKKnNgpoOloSso4w' },
      { label: '720P', url: 'https://www.terabox.app/sharing/embed?surl=93MmrOLKKnNgpoOloSso4w' },
    ],
  },
  {
    id: 'vid-suzume-anime',
    title: 'Suzume No Tojimari - Emotional Weather Journey (TeraBox Stream 1080P)',
    slug: 'suzume-no-tojimari-emotional-weather-journey',
    description: 'High definition atmospheric cut from Makoto Shinkai’s acclaimed masterpiece Suzume. Experience stunning visual fidelity, rich soundstage, and seamless playback directly on our platform.',
    thumbnail: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1280&auto=format&fit=crop&q=80',
    videoUrl: 'https://1024terabox.com/s/1DR0LCZe0GRoy6RkIL-3mmA',
    embedUrl: 'https://www.terabox.app/sharing/embed?surl=DR0LCZe0GRoy6RkIL-3mmA',
    teraboxShareId: 'DR0LCZe0GRoy6RkIL-3mmA',
    sourceType: 'terabox',
    category: 'anime',
    tags: ['Anime', 'Suzume', 'Makoto Shinkai', 'TeraBox Stream', '1080P'],
    duration: 184,
    durationFormatted: '03:04',
    views: 14820,
    likes: 1240,
    dislikes: 18,
    featured: true,
    trending: true,
    status: 'published',
    createdAt: '2026-10-18T10:00:00.000Z',
    updatedAt: '2026-10-18T10:00:00.000Z',
    resolutions: [
      { label: '1080P', url: 'https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-1080p.mp4' },
      { label: '720P', url: 'https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-720p.mp4' },
      { label: '480P', url: 'https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-576p.mp4' },
    ],
  },
  {
    id: 'vid-blue-moon',
    title: 'View From A Blue Moon - Cinematic 4K Surf & Adventure Showcase',
    slug: 'view-from-a-blue-moon-adventure',
    description: 'The first surf film shot in 4K, following the world’s most dynamic surfer, John Florence, and his closest friends from his home in Oahu to the top surfing destinations around the globe.',
    thumbnail: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1280&auto=format&fit=crop&q=80',
    videoUrl: 'https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-1080p.mp4',
    sourceType: 'direct',
    category: 'movies',
    tags: ['Cinema', 'Surfing', 'Extreme Sports', 'Adventure', '4K UHD'],
    duration: 195,
    durationFormatted: '03:15',
    views: 29540,
    likes: 2180,
    dislikes: 32,
    featured: true,
    trending: true,
    status: 'published',
    createdAt: '2026-10-17T14:30:00.000Z',
    updatedAt: '2026-10-17T14:30:00.000Z',
    resolutions: [
      { label: '1080P', url: 'https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-1080p.mp4' },
      { label: '720P', url: 'https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-720p.mp4' },
      { label: '480P', url: 'https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-576p.mp4' },
    ],
  },
  {
    id: 'vid-deep-oceans',
    title: 'Oceans: The Unknown Depths (HD Marine Wildlife Odyssey)',
    slug: 'oceans-unknown-depths-wildlife',
    description: 'Dive deep beneath the surface to explore breathtaking ecosystems, vibrant coral barriers, and magnificent aquatic creatures captured with state-of-the-art marine cameras.',
    thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1280&auto=format&fit=crop&q=80',
    videoUrl: 'https://vjs.zencdn.net/v/oceans.mp4',
    sourceType: 'direct',
    category: 'movies',
    tags: ['Nature', 'Documentary', 'Marine Life', 'Wildlife', 'HD'],
    duration: 246,
    durationFormatted: '04:06',
    views: 18920,
    likes: 1650,
    dislikes: 14,
    featured: false,
    trending: true,
    status: 'published',
    createdAt: '2026-10-16T09:15:00.000Z',
    updatedAt: '2026-10-16T09:15:00.000Z',
    resolutions: [
      { label: '1080P', url: 'https://vjs.zencdn.net/v/oceans.mp4' },
      { label: '720P', url: 'https://vjs.zencdn.net/v/oceans.mp4' },
    ],
  },
  {
    id: 'vid-cyberpunk-tokyo',
    title: 'Neon Nights Tokyo: Cyberpunk Streetwalker & Synthwave Ambience',
    slug: 'neon-nights-tokyo-cyberpunk-synthwave',
    description: 'Immerse yourself in rainy neon lit alleys of Shinjuku and Akihabara with chilling retro synthwave soundtrack. Perfect for focus, gaming, and relaxing vibe sessions.',
    thumbnail: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=1280&auto=format&fit=crop&q=80',
    videoUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    embedUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    sourceType: 'hls',
    category: 'music',
    tags: ['Music', 'Cyberpunk', 'Synthwave', 'Tokyo', 'Lo-Fi'],
    duration: 634,
    durationFormatted: '10:34',
    views: 34100,
    likes: 3120,
    dislikes: 45,
    featured: true,
    trending: true,
    status: 'published',
    createdAt: '2026-10-15T18:00:00.000Z',
    updatedAt: '2026-10-15T18:00:00.000Z',
  },
  {
    id: 'vid-react-next-ai',
    title: 'Modern Full-Stack Web Development with React 19 & Cloud Functions',
    slug: 'modern-fullstack-web-development-react',
    description: 'Complete hands-on breakdown for modern reactive frontend architectures, responsive glassmorphism interfaces, state management, and edge deployments.',
    thumbnail: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=1280&auto=format&fit=crop&q=80',
    videoUrl: 'https://media.w3.org/2010/05/sintel/trailer.mp4',
    sourceType: 'direct',
    category: 'tutorials',
    tags: ['Tech', 'Coding', 'React', 'TypeScript', 'WebDev'],
    duration: 312,
    durationFormatted: '05:12',
    views: 8930,
    likes: 890,
    dislikes: 9,
    featured: false,
    trending: false,
    status: 'published',
    createdAt: '2026-10-14T11:20:00.000Z',
    updatedAt: '2026-10-14T11:20:00.000Z',
  },
  {
    id: 'vid-viral-action-cut',
    title: 'Top 10 Insane Stunt Moments & Cinematic Combat Cuts 2026',
    slug: 'top-10-insane-stunt-moments-cinematic',
    description: 'The most mind-boggling stunt choreographies, behind-the-scenes wire work, and high-speed chase sequences caught on camera in one adrenaline-pumping compilation.',
    thumbnail: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1280&auto=format&fit=crop&q=80',
    videoUrl: 'https://1024terabox.com/s/1DR0LCZe0GRoy6RkIL-3mmA',
    embedUrl: 'https://www.terabox.app/sharing/embed?surl=DR0LCZe0GRoy6RkIL-3mmA',
    teraboxShareId: 'DR0LCZe0GRoy6RkIL-3mmA',
    sourceType: 'terabox',
    category: 'clips',
    tags: ['Action', 'Stunts', 'Viral', 'Movie Clips', 'Compilation'],
    duration: 185,
    durationFormatted: '03:05',
    views: 45620,
    likes: 4120,
    dislikes: 88,
    featured: false,
    trending: true,
    status: 'published',
    createdAt: '2026-10-13T16:45:00.000Z',
    updatedAt: '2026-10-13T16:45:00.000Z',
  },
];

// Clean, empty ad slots. Nothing is shown to visitors until you paste real Adsterra code and switch a slot on.
export const DEFAULT_ADS: AdUnit[] = SLOT_CATALOG.map((slot) => ({
  id: slot.id,
  name: slot.name,
  position: slot.position,
  enabled: false,
  type: slot.mode === 'global' || slot.mode === 'popunder' ? 'script' : 'adsterra',
  dimensions: slot.dimensions,
  deviceTarget: 'all',
  code: '',
  mobileCode: '',
  notes: `${slot.where} ${slot.how}`,
}));

export const DEFAULT_SETTINGS: SiteSettings = {
  siteName: 'TeraStream',
  tagline: 'Movies, anime aur series — ek hi jagah, cinematic HD mein.',
  logoText: 'TERASTREAM',
  logoUrl: '',
  announcementText: '',
  showAnnouncement: false,
  announcementLink: '',
  defaultMetaDescription: 'Watch movies, anime and series online in HD with a fast, mobile-friendly player.',
  defaultKeywords: 'watch online, movies, anime, series, hd streaming',
  footerText: '© 2026 TeraStream. All rights reserved.',
  telegramUrl: '',
  whatsappUrl: '',
  twitterUrl: '',
  discordUrl: '',
  adblockNoticeTitle: 'Ad-Blocker Detected',
  adblockNoticeMessage: 'Please support our free video streaming platform by whitelisting us in your ad-blocker. We keep our ads safe and non-intrusive!',
  showAdblockNotice: true,
  contactEmail: '',
  popunderFrequencyHours: 24,
  showIntermediatePage: false,
  intermediateWaitSeconds: 5,
};

export const DEFAULT_COMMENTS: VideoComment[] = [
  {
    id: 'c1',
    videoId: 'vid-suzume-anime',
    userName: 'Alex Rivera',
    userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80',
    content: 'The video stream loaded instantly without any redirection! Truly love this player UI and theater mode.',
    createdAt: '2 hours ago',
    likes: 24,
  },
  {
    id: 'c2',
    videoId: 'vid-suzume-anime',
    userName: 'Sakura M.',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80',
    content: 'Makoto Shinkai’s animations are forever legendary. Thanks for compiling this in full clarity!',
    createdAt: '5 hours ago',
    likes: 18,
  },
  {
    id: 'c3',
    videoId: 'vid-blue-moon',
    userName: 'David Vance',
    userAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=100&auto=format&fit=crop&q=80',
    content: 'The 4K surfing photography is out of this world. Played smoothly on mobile too.',
    createdAt: '1 day ago',
    likes: 31,
  },
];

class StorageService {
  private get<T>(key: string, defaultValue: T): T {
    try {
      const item = localStorage.getItem(key);
      if (!item) return defaultValue;
      return JSON.parse(item) as T;
    } catch (e) {
      console.error(`Error reading ${key} from localStorage`, e);
      return defaultValue;
    }
  }

  /** `sync = true` marks an admin change that must reach the server (and so every visitor). */
  private set<T>(key: string, value: T, sync = false): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error(`Error writing ${key} to localStorage`, e);
    }
    if (sync) {
      this.bump();
      this.pushToServer(key, value);
    }
  }

  // ---- change notifications (components re-render when admin data changes, locally or from the server)
  private version = 0;
  private listeners = new Set<() => void>();
  subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  }
  getVersion(): number {
    return this.version;
  }
  private bump(): void {
    this.version++;
    this.listeners.forEach((fn) => fn());
  }

  private pushChain: Promise<void> = Promise.resolve();
  private pending = 0;
  private lastPushAt = 0;

  private pushToServer<T>(localKey: string, value: T): void {
    const serverKey = Object.keys(SERVER_SYNCED).find((k) => SERVER_SYNCED[k] === localKey);
    if (!serverKey) return;
    if (!adminApi.hasSession()) {
      toast.error('Admin login expired - is change ko sab devices par dikhane ke liye dobara login karein.');
      return;
    }
    this.pending++;
    this.pushChain = this.pushChain
      .then(() => adminApi.pushStore(serverKey, value))
      .then(() => {
        toast.success('Server par save ho gaya - ab sab devices par dikhega', { id: 'cm-sync-ok' });
      })
      .catch((e) => {
        console.error(`Failed to save ${serverKey} on server`, e);
        toast.error(`Server par save NAHI hua: ${e instanceof Error ? e.message : 'unknown error'}. Ye change dusre devices par nahi dikhega.`, { id: 'cm-sync-fail' });
      })
      .finally(() => {
        this.pending--;
        this.lastPushAt = Date.now();
      });
  }

  /**
   * Load the shared site data from the server into this browser's cache. Call before rendering and
   * after admin login. If the server has no copy yet (first run) and an admin is logged in, this
   * browser's existing data is uploaded once, so nothing already set up is lost.
   */
  async hydrateFromServer(): Promise<boolean> {
    if (this.pending > 0) return false;
    const remote = await adminApi.fetchStore();
    if (!remote) return false; // server unreachable: keep working from the cache
    if (this.pending > 0 || Date.now() - this.lastPushAt < 4000) return false; // an admin save is in flight - do not overwrite it
    let changed = false;
    for (const [serverKey, localKey] of Object.entries(SERVER_SYNCED)) {
      try {
        if (remote[serverKey] !== undefined) {
          let value: unknown = remote[serverKey];
          if (serverKey === 'videos' && Array.isArray(value)) value = this.keepLocalCounters(value as VideoItem[]);
          const next = JSON.stringify(value);
          if (localStorage.getItem(localKey) !== next) {
            localStorage.setItem(localKey, next);
            changed = true;
          }
        } else if (adminApi.hasSession()) {
          const raw = localStorage.getItem(localKey);
          if (raw) this.pushToServer(localKey, JSON.parse(raw));
        }
      } catch (e) {
        console.error(`Could not sync ${serverKey}`, e);
      }
    }
    if (changed) this.bump();
    return true;
  }

  /** Views / likes are counted per device; do not let a refresh from the server reset them. */
  private keepLocalCounters(remote: VideoItem[]): VideoItem[] {
    const local = this.get<VideoItem[]>(STORAGE_KEYS.VIDEOS, []);
    const byId = new Map(local.map((v) => [v.id, v]));
    return remote.map((v) => {
      const l = byId.get(v.id);
      if (!l) return v;
      return { ...v, views: Math.max(v.views || 0, l.views || 0), likes: Math.max(v.likes || 0, l.likes || 0), dislikes: Math.max(v.dislikes || 0, l.dislikes || 0) };
    });
  }

  /** Keep every open page / phone in sync with the admin panel without a manual refresh. */
  private syncStarted = false;
  startBackgroundSync(): void {
    if (this.syncStarted || typeof window === 'undefined') return;
    this.syncStarted = true;
    let last = Date.now();
    const refresh = () => {
      if (document.hidden) return;
      if (Date.now() - last < 8000) return;
      last = Date.now();
      void this.hydrateFromServer();
    };
    window.setInterval(refresh, 30000);
    document.addEventListener('visibilitychange', refresh);
    window.addEventListener('focus', refresh);
    window.addEventListener('online', refresh);
    window.addEventListener('pageshow', refresh);
  }

  // Videos
  getVideos(): VideoItem[] {
    const list = this.get<VideoItem[]>(STORAGE_KEYS.VIDEOS, []);
    let items = list;
    if (!items || items.length === 0) {
      this.set(STORAGE_KEYS.VIDEOS, DEFAULT_VIDEOS);
      items = DEFAULT_VIDEOS;
    }

    // Auto-repair and ensure all videos have valid thumbnails & playable streams
    return items.map((v, i) => {
      const shareId = v.teraboxShareId || extractTeraboxShareId(v.videoUrl) || undefined;
      const thumbnail =
        v.thumbnail && v.thumbnail.trim().length > 0
          ? v.thumbnail
          : DEFAULT_POSTERS[i % DEFAULT_POSTERS.length];
      const embedUrl =
        v.embedUrl || (shareId ? buildTeraboxEmbedUrl(shareId) : undefined);
      const resolutions =
        v.resolutions && v.resolutions.length > 0
          ? v.resolutions
          : DEFAULT_ADAPTIVE_STREAMS;

      return {
        ...v,
        thumbnail,
        teraboxShareId: shareId,
        embedUrl,
        resolutions,
        durationFormatted: v.durationFormatted || formatDuration(v.duration || 180),
      };
    });
  }

  getVideoById(id: string): VideoItem | undefined {
    const videos = this.getVideos();
    return videos.find((v) => v.id === id || v.slug === id);
  }

  saveVideo(video: VideoItem): VideoItem {
    const videos = this.getVideos();
    const index = videos.findIndex((v) => v.id === video.id);
    const shareId = video.teraboxShareId || extractTeraboxShareId(video.videoUrl) || undefined;
    const thumbnail =
      video.thumbnail && video.thumbnail.trim().length > 0
        ? video.thumbnail.trim()
        : DEFAULT_POSTERS[0];
    const embedUrl =
      video.embedUrl || (shareId ? buildTeraboxEmbedUrl(shareId) : undefined);
    const resolutions =
      video.resolutions && video.resolutions.length > 0
        ? video.resolutions
        : DEFAULT_ADAPTIVE_STREAMS;

    const updated: VideoItem = {
      ...video,
      thumbnail,
      teraboxShareId: shareId,
      embedUrl,
      resolutions,
      updatedAt: new Date().toISOString(),
      durationFormatted: formatDuration(video.duration || 180),
    };

    if (index >= 0) {
      videos[index] = updated;
    } else {
      videos.unshift(updated);
    }
    this.set(STORAGE_KEYS.VIDEOS, videos, true);
    return updated;
  }

  deleteVideo(id: string): boolean {
    const videos = this.getVideos();
    const filtered = videos.filter((v) => v.id !== id);
    if (filtered.length !== videos.length) {
      this.set(STORAGE_KEYS.VIDEOS, filtered, true);
      return true;
    }
    return false;
  }

  incrementViews(id: string): void {
    const videos = this.getVideos();
    const video = videos.find((v) => v.id === id);
    if (video) {
      video.views = (video.views || 0) + 1;
      this.set(STORAGE_KEYS.VIDEOS, videos);
    }
  }

  toggleLike(id: string, isLike: boolean): { likes: number; dislikes: number } {
    const videos = this.getVideos();
    const video = videos.find((v) => v.id === id);
    if (!video) return { likes: 0, dislikes: 0 };

    if (isLike) {
      video.likes = (video.likes || 0) + 1;
    } else {
      video.dislikes = (video.dislikes || 0) + 1;
    }
    this.set(STORAGE_KEYS.VIDEOS, videos);
    return { likes: video.likes, dislikes: video.dislikes };
  }

  // Categories
  getCategories(): CategoryItem[] {
    const list = this.get<CategoryItem[]>(STORAGE_KEYS.CATEGORIES, []);
    if (!list || list.length === 0) {
      this.set(STORAGE_KEYS.CATEGORIES, DEFAULT_CATEGORIES);
      return DEFAULT_CATEGORIES;
    }
    return list;
  }

  saveCategory(category: CategoryItem): void {
    const categories = this.getCategories();
    const index = categories.findIndex((c) => c.id === category.id);
    if (index >= 0) {
      categories[index] = category;
    } else {
      categories.push(category);
    }
    this.set(STORAGE_KEYS.CATEGORIES, categories, true);
  }

  deleteCategory(id: string): void {
    const categories = this.getCategories().filter((c) => c.id !== id);
    this.set(STORAGE_KEYS.CATEGORIES, categories, true);
  }

  // Ads
  getAds(): AdUnit[] {
    const list = this.get<AdUnit[]>(STORAGE_KEYS.ADS, []);
    const known = Array.isArray(list) ? list : [];
    let dirty = known.length === 0;
    // 1) wipe the fake demo ads that older versions shipped; 2) make sure every slot exists exactly once
    const cleaned = known.map((ad) => {
      if (isPlaceholderCode(ad.code) || isPlaceholderCode(ad.mobileCode)) {
        dirty = true;
        return { ...ad, code: isPlaceholderCode(ad.code) ? '' : ad.code, mobileCode: isPlaceholderCode(ad.mobileCode) ? '' : ad.mobileCode, enabled: isPlaceholderCode(ad.code) ? false : ad.enabled };
      }
      return ad;
    });
    const positions = new Set(cleaned.map((ad) => ad.position));
    const missing = DEFAULT_ADS.filter((d) => !positions.has(d.position));
    if (missing.length) dirty = true;
    const merged = [...cleaned, ...missing].map((ad) => ({ ...ad, deviceTarget: ad.deviceTarget || 'all' }));
    const result = merged;
    if (dirty) this.set(STORAGE_KEYS.ADS, result); // local cache only
    return result;
  }

  saveAd(ad: AdUnit): void {
    const ads = this.getAds();
    const index = ads.findIndex((a) => a.id === ad.id);
    if (index >= 0) {
      ads[index] = ad;
    } else {
      ads.push(ad);
    }
    this.set(STORAGE_KEYS.ADS, ads, true);
  }

  deleteAd(id: string): void {
    const ads = this.getAds().filter((a) => a.id !== id);
    this.set(STORAGE_KEYS.ADS, ads, true);
  }

  // Settings
  getSettings(): SiteSettings {
    const current = this.get<SiteSettings | null>(STORAGE_KEYS.SETTINGS, null);
    if (!current) {
      this.set(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
      return DEFAULT_SETTINGS;
    }
    const merged: SiteSettings = { ...DEFAULT_SETTINGS, ...current };
    // older versions shipped placeholder texts / links: hide them (anything the owner typed themselves is kept)
    if (/Welcome to TeraStream Hub/i.test(merged.announcementText || '')) {
      merged.announcementText = '';
      merged.showAnnouncement = false;
    }
    // rebrand migration: earlier builds shipped as "CineMitra"; rename cached defaults
    // (anything the admin typed themselves is kept)
    if (/^cinemitra$/i.test(merged.siteName || '')) merged.siteName = DEFAULT_SETTINGS.siteName;
    if (/^cinemitra$/i.test(merged.logoText || '')) merged.logoText = DEFAULT_SETTINGS.logoText;
    if (/cinemitra/i.test(merged.footerText || '')) {
      merged.footerText = merged.footerText.replace(/cinemitra/gi, 'TeraStream');
    }
    if (/Designed for fast cloud streaming and seamless social video sharing/i.test(merged.footerText || '')) merged.footerText = DEFAULT_SETTINGS.footerText;
    for (const k of ['telegramUrl', 'whatsappUrl', 'twitterUrl', 'discordUrl'] as const) {
      if (/^https:\/\/(t\.me|whatsapp\.com|twitter\.com|discord\.com)\/?$/i.test(merged[k] || '')) merged[k] = '';
    }
    if (/@cinemitra\.example$/i.test(merged.contactEmail || '')) merged.contactEmail = '';
    return merged;
  }

  saveSettings(settings: SiteSettings): void {
    this.set(STORAGE_KEYS.SETTINGS, settings, true);
  }

  // Comments
  getComments(videoId: string): VideoComment[] {
    const all = this.get<VideoComment[]>(STORAGE_KEYS.COMMENTS, DEFAULT_COMMENTS);
    return all.filter((c) => c.videoId === videoId);
  }

  addComment(videoId: string, userName: string, content: string): VideoComment {
    const all = this.get<VideoComment[]>(STORAGE_KEYS.COMMENTS, DEFAULT_COMMENTS);
    const newComment: VideoComment = {
      id: `comment-${Date.now()}`,
      videoId,
      userName: userName.trim() || 'Anonymous Viewer',
      content: content.trim(),
      createdAt: 'Just now',
      likes: 0,
    };
    all.unshift(newComment);
    this.set(STORAGE_KEYS.COMMENTS, all);
    return newComment;
  }

  // Interactions (Watchlist, reactions, history)
  getUserInteractions(): UserInteractionState {
    return this.get<UserInteractionState>(STORAGE_KEYS.INTERACTIONS, {
      likedVideos: [],
      dislikedVideos: [],
      emojiReactions: {},
      watchlist: [],
      history: [],
    });
  }

  saveUserInteractions(state: UserInteractionState): void {
    this.set(STORAGE_KEYS.INTERACTIONS, state);
  }

  toggleWatchlist(videoId: string): boolean {
    const state = this.getUserInteractions();
    const exists = state.watchlist.includes(videoId);
    if (exists) {
      state.watchlist = state.watchlist.filter((id) => id !== videoId);
    } else {
      state.watchlist.unshift(videoId);
    }
    this.saveUserInteractions(state);
    return !exists;
  }

  recordReaction(videoId: string, emoji: string): void {
    const state = this.getUserInteractions();
    state.emojiReactions[videoId] = emoji;
    this.saveUserInteractions(state);
  }

  // Admin Auth Session (checked by the server; this only says whether a session token is stored)
  isAdminAuthenticated(): boolean {
    return adminApi.hasSession();
  }

  async adminLogin(password: string): Promise<void> {
    await adminApi.login(password);
    await this.hydrateFromServer();
  }

  adminLogout(): void {
    adminApi.clearSession();
  }
}

export const storageService = new StorageService();
