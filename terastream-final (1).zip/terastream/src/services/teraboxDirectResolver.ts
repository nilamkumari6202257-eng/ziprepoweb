import { VideoResolutionOption } from '@/types/video';
import { ndusTokenService } from './ndusTokenService';
import { isDirectMediaUrl } from './teraboxParser';

/**
 * Self-hosted TeraBox API (server/terabox.mjs). Same-origin by default, so it works with
 * `npm run dev` and `npm start` with no extra setup. Set VITE_TERABOX_API_BASE only if the API
 * is hosted on a different domain.
 */
export const TERABOX_API_URL: string =
  (import.meta.env.VITE_TERABOX_API_BASE as string | undefined)?.trim() || '/api/terabox';

/** The server returns relative stream URLs ("?action=playlist...") so they work behind any proxy / https setup.
 *  Turn them into absolute URLs against the API address we actually called. */
function absoluteApiUrl(u: string): string {
  try {
    const apiAbs = new URL(TERABOX_API_URL, window.location.href);
    return new URL(u, apiAbs).toString();
  } catch {
    return u;
  }
}

export interface ResolveStreamResult {
  success: boolean;
  streamUrl?: string;
  resolutions?: VideoResolutionOption[];
  title?: string;
  duration?: number;
  thumbnail?: string;
  usedToken?: string;
  tokenLabel?: string;
  error?: string;
  switchedToken?: boolean;
  isHls?: boolean;
  previewLimited?: boolean;
}

/**
 * Resolves a TeraBox video URL into a playable M3U8 stream
 * via the self-hosted /api/terabox endpoint. VIP ndus tokens (admin panel + .env) are kept on the server and
 * the server fails over between them by itself.
 */
export async function resolveTeraboxStreamWithAutoSwitch(
  inputUrlOrShareId: string,
  maxRetries = 2
): Promise<ResolveStreamResult> {
  const trimmed = inputUrlOrShareId.trim();
  if (!trimmed) {
    return { success: false, error: 'Empty video link provided.' };
  }

  // If it's already a direct video or HLS file, return immediately
  if (isDirectMediaUrl(trimmed)) {
    const isHls = trimmed.split('?')[0].toLowerCase().endsWith('.m3u8');
    return {
      success: true,
      streamUrl: trimmed,
      isHls,
      title: 'Direct Video Stream',
      // a single fixed file has no renditions - the player shows native HLS levels for master playlists
      resolutions: [{ label: 'Auto', url: trimmed }],
    };
  }

  let attempt = 0;
  let lastError = '';
  const tokenSwitchedDuringResolution = false;

  // Build a normalized TeraBox link if only a shareId was passed
  let targetUrl = trimmed;
  if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
    const cleanId = trimmed.replace(/^1/, '');
    targetUrl = `https://1024terabox.com/s/1${cleanId}`;
  }

  while (attempt <= maxRetries) {
    const activeTokenItem = ndusTokenService.getActiveToken();
    const tokenStr = activeTokenItem?.token?.trim() || '';

    try {
      const endpoint = `${TERABOX_API_URL}?action=resolve&url=${encodeURIComponent(targetUrl)}`;

      // No token is sent from the browser: the server picks from its own pool (admin-panel + .env tokens),
      // so playback is identical on every device.
      const headers: Record<string, string> = { Accept: 'application/json' };

      const res = await fetch(endpoint, { method: 'GET', headers });

      const data = await res.json().catch(() => null);

      if (res.ok && (data?.url || data?.embedUrl)) {
        const streamUrl = absoluteApiUrl(data.url || data.embedUrl);
        const resolutions: VideoResolutionOption[] = (data.resolutions || []).map((r: any) => ({
          label: r.label || 'HD',
          url: r.url ? absoluteApiUrl(r.url) : streamUrl,
          height: r.label === '1080P' ? 1080 : r.label === '720P' ? 720 : 480,
        }));

        if (resolutions.length === 0) {
          resolutions.push({ label: 'Auto', url: streamUrl });
        }

        return {
          success: true,
          streamUrl,
          isHls: typeof streamUrl === 'string' && (streamUrl.includes('.m3u8') || streamUrl.includes('action=playlist')),
          title: data.title || 'TeraBox VIP Stream',
          duration: data.duration || 0,
          previewLimited: Boolean(data.preview_limited),
          resolutions,
          usedToken: tokenStr,
          tokenLabel: data.token_label || activeTokenItem?.label || 'Server VIP Token',
          switchedToken: tokenSwitchedDuringResolution,
        };
      }

      // Check if unauthorized, expired token, or error
      const errMsg =
        data?.error ||
        (data
          ? res.statusText || 'Failed to resolve stream'
          : 'Video API reachable nahi hai. Site ko Node server par chalayein (npm start / Docker) - sirf static hosting par video nahi chalega.');
      lastError = errMsg;

      // Dead / invalid link: retrying won't help (server already tried every token)
      if (res.status === 404) break;

      // Other error
      attempt++;
    } catch (err: any) {
      lastError = err?.message || 'Network error reaching stream resolver';
      attempt++;
    }
  }

  return {
    success: false,
    error: lastError || 'Could not stream this link right now. It may be private or deleted.',
  };
}
