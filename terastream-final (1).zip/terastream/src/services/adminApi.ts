// Client for the server-side admin API (server/admin.mjs).
// Admin-panel changes are saved on the SERVER so every visitor / device sees them.

const TERABOX_BASE: string =
  (import.meta.env.VITE_TERABOX_API_BASE as string | undefined)?.trim() || '/api/terabox';
const ADMIN_BASE = TERABOX_BASE.replace(/\/terabox\/?$/, '/admin');

const SESSION_KEY = 'tb_stream_admin_session_v2';

function getSession(): string {
  try {
    return localStorage.getItem(SESSION_KEY) || '';
  } catch {
    return '';
  }
}

async function request(
  action: string,
  opts: { method?: string; body?: unknown; query?: Record<string, string>; auth?: boolean; timeoutMs?: number } = {}
): Promise<any> {
  const params = new URLSearchParams({ action, ...(opts.query || {}) });
  const headers: Record<string, string> = { Accept: 'application/json' };
  if (opts.body !== undefined) headers['Content-Type'] = 'application/json';
  if (opts.auth) headers['X-Admin-Token'] = getSession();

  const ctrl = new AbortController();
  const timer = opts.timeoutMs ? setTimeout(() => ctrl.abort(), opts.timeoutMs) : null;
  try {
    const res = await fetch(`${ADMIN_BASE}?${params}`, {
      method: opts.method || 'GET',
      headers,
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
      signal: ctrl.signal,
    });
    const data = await res.json().catch(() => null);
    if (res.status === 401 && opts.auth) {
      adminApi.clearSession();
      throw new Error('Admin session expired. Please log in again.');
    }
    if (!res.ok) throw new Error(data?.error || `Server error (${res.status})`);
    return data;
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export const adminApi = {
  hasSession: (): boolean => Boolean(getSession()),

  clearSession(): void {
    try {
      localStorage.removeItem(SESSION_KEY);
    } catch {
      /* ignore */
    }
  },

  async login(password: string): Promise<void> {
    const data = await request('login', { method: 'POST', body: { password } });
    try {
      localStorage.setItem(SESSION_KEY, data.token);
    } catch {
      throw new Error('Browser storage is blocked; cannot keep you logged in.');
    }
  },

  /** Public site data (videos, categories, ads, settings). null if the server is unreachable. */
  async fetchStore(timeoutMs = 12000): Promise<Record<string, unknown> | null> {
    // Phones on slow networks (and big base64 thumbnails) need more than 3s - give it a real chance and retry once.
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        return await request('store', { timeoutMs, query: { _t: String(Date.now()) } });
      } catch {
        /* retry */
      }
    }
    return null;
  },

  async pushStore(key: string, value: unknown): Promise<void> {
    await request('store', { method: 'PUT', query: { key }, body: { value }, auth: true });
  },

  /** Token pool (admin only). null on failure. */
  async fetchTokens(timeoutMs = 3000): Promise<any[] | null> {
    try {
      const data = await request('tokens', { auth: true, timeoutMs });
      return Array.isArray(data?.tokens) ? data.tokens : null;
    } catch {
      return null;
    }
  },

  /** Admin only: step-by-step report of how a TeraBox link resolves on THIS server (which token, which step fails). */
  async diagnoseLink(link: string): Promise<{
    ok: boolean; status: number; error?: string; token_used?: string; preview_only?: boolean;
    preview_seconds?: number; full_duration?: number; title?: string; steps: string[];
  }> {
    const res = await fetch(`${TERABOX_BASE}?action=diagnose&url=${encodeURIComponent(link)}`, {
      headers: { Accept: 'application/json', 'X-Admin-Token': getSession() },
    });
    const data = await res.json().catch(() => null);
    if (res.status === 401) throw new Error('Admin session expired. Please log in again.');
    if (!data) throw new Error('Server ne JSON nahi diya - site Node server par chal rahi hai?');
    return data;
  },

  async pushTokens(list: unknown[]): Promise<void> {
    await request('tokens', { method: 'PUT', body: { value: list }, auth: true });
  },
};
