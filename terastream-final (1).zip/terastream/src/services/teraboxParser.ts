import { VideoItem, VideoResolutionOption } from '@/types/video';
import { ndusTokenService } from '@/services/ndusTokenService';

export const SUPPORTED_TERABOX_HOSTS_REGEX = /(terabox|teraboxapp|1024terabox|4funbox|mirrobox|nephobox|freeterabox|momerybox|tibibox|teraboxlink|terabox\.app)\./i;

/**
 * Extracts Terabox share ID from links
 * Supports:
 * - https://terabox.com/s/1DR0LCZe0GRoy6RkIL-3mmA
 * - https://1024terabox.com/s/1DR0LCZe0GRoy6RkIL-3mmA
 * - https://teraboxapp.com/sharing/link?surl=DR0LCZe0GRoy6RkIL-3mmA
 * - https://nephobox.com/s/1DR0...
 * - iframe codes: <iframe src="...">
 */
export function extractTeraboxShareId(input: string): string | null {
  if (!input) return null;
  const trimmed = input.trim();

  // If iframe passed
  const iframeMatch = trimmed.match(/src=["']([^"']+)["']/i);
  const target = iframeMatch ? iframeMatch[1] : trimmed;

  try {
    const url = new URL(target.startsWith('http') ? target : `https://${target}`);
    
    // Check hostname
    if (SUPPORTED_TERABOX_HOSTS_REGEX.test(url.hostname)) {
      const surl = url.searchParams.get('surl');
      if (surl) {
        return surl.replace(/^1/, '');
      }
      const pathMatch = url.pathname.match(/\/s\/1?([A-Za-z0-9_-]+)/);
      if (pathMatch) {
        return pathMatch[1];
      }
    }
    return null;
  } catch {
    // regex fallback on raw string
    const match = trimmed.match(/(?:s\/1?|surl=1?)([A-Za-z0-9_-]{10,40})/i);
    return match ? match[1] : null;
  }
}

/**
 * Checks if input is an HTML iframe tag
 */
export function extractIframeSrc(input: string): string | null {
  if (!input) return null;
  const match = input.match(/<iframe[^>]*\s+src=["']([^"']+)["'][^>]*>/i);
  return match ? match[1] : null;
}

/**
 * Checks whether URL is a direct media file (mp4, m3u8, webm)
 */
export function isDirectMediaUrl(url: string): boolean {
  if (!url) return false;
  const clean = url.split('?')[0].toLowerCase();
  return clean.endsWith('.mp4') || clean.endsWith('.m3u8') || clean.endsWith('.webm') || clean.endsWith('.ogg');
}

/**
 * Formats duration in seconds to standard HH:MM:SS or MM:SS
 */
export function formatDuration(seconds: number): string {
  if (!seconds || isNaN(seconds) || seconds <= 0) return '00:00';
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);

  if (hrs > 0) {
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

export interface TeraboxMirror {
  id: string;
  name: string;
  url: string;
  type: 'embed' | 'web';
  badge: string;
}

/**
 * Returns available server mirrors for a given Terabox share ID,
 * appending the active ndus token when available for VIP unblocking.
 */
export function getTeraboxMirrors(shareId: string, customToken?: string): TeraboxMirror[] {
  const cleanId = shareId.replace(/^1/, '');
  const activeToken = customToken || ndusTokenService.getActiveTokenString();
  const tokenQuery = activeToken ? `&ndus=${encodeURIComponent(activeToken)}` : '';

  return [
    {
      id: '1024tera',
      name: '1024Tera (VIP Server - Ultra Fast)',
      url: `https://www.1024tera.com/sharing/embed?surl=${cleanId}${tokenQuery}`,
      type: 'embed',
      badge: 'Fast VIP',
    },
    {
      id: 'teraboxapp',
      name: 'TeraBox App (Official Stream)',
      url: `https://www.terabox.app/sharing/embed?surl=${cleanId}${tokenQuery}`,
      type: 'embed',
      badge: 'Official',
    },
    {
      id: 'teraboxglobal',
      name: 'TeraBox Global (terabox.com)',
      url: `https://www.terabox.com/sharing/embed?surl=${cleanId}${tokenQuery}`,
      type: 'embed',
      badge: 'Global',
    },
    {
      id: 'nephobox',
      name: 'NephoBox Cloud Mirror',
      url: `https://www.nephobox.com/sharing/embed?surl=${cleanId}${tokenQuery}`,
      type: 'embed',
      badge: 'Mirror',
    },
    {
      id: '4funbox',
      name: '4FunBox Cloud Stream',
      url: `https://www.4funbox.com/sharing/embed?surl=${cleanId}${tokenQuery}`,
      type: 'embed',
      badge: 'Backup',
    },
  ];
}

/**
 * Direct web url to play directly on clean TeraBox page with Ndus auth
 */
export function getTeraboxDirectWebUrl(shareId: string, customToken?: string): string {
  const cleanId = shareId.replace(/^1/, '');
  const activeToken = customToken || ndusTokenService.getActiveTokenString();
  const tokenParam = activeToken ? `?ndus=${encodeURIComponent(activeToken)}` : '';
  return `https://www.1024tera.com/sharing/link?surl=${cleanId}${tokenParam}`;
}

export const DEFAULT_ADAPTIVE_STREAMS: VideoResolutionOption[] = [
  { label: '1080P', url: 'https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-1080p.mp4', height: 1080 },
  { label: '720P', url: 'https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-720p.mp4', height: 720 },
  { label: '480P', url: 'https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-576p.mp4', height: 480 },
  { label: '360P', url: 'https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-576p.mp4', height: 360 },
];

/**
 * Builds an embed URL for a Terabox share ID with active Ndus token
 */
export function buildTeraboxEmbedUrl(shareId: string, customToken?: string): string {
  const cleanId = shareId.replace(/^1/, '');
  const activeToken = customToken || ndusTokenService.getActiveTokenString();
  const tokenQuery = activeToken ? `&ndus=${encodeURIComponent(activeToken)}` : '';
  return `https://www.1024tera.com/sharing/embed?surl=${cleanId}${tokenQuery}`;
}

/**
 * Converts any raw input (URL, iframe, link) into a standardized VideoItem partial
 */
export function parseVideoSource(input: string, title?: string): Partial<VideoItem> {
  const trimmed = input.trim();
  
  // Case 1: Raw iframe
  const iframeSrc = extractIframeSrc(trimmed);
  if (iframeSrc) {
    const shareId = extractTeraboxShareId(iframeSrc);
    return {
      videoUrl: trimmed,
      embedUrl: iframeSrc,
      sourceType: 'embed',
      teraboxShareId: shareId || undefined,
      title: title || 'Embedded Stream Video',
    };
  }

  // Case 2: Terabox link
  const shareId = extractTeraboxShareId(trimmed);
  if (shareId) {
    return {
      videoUrl: trimmed,
      embedUrl: buildTeraboxEmbedUrl(shareId),
      sourceType: 'terabox',
      teraboxShareId: shareId,
      title: title || `TeraBox Video [${shareId.slice(0, 8)}]`,
    };
  }

  // Case 3: Direct HLS or MP4
  if (isDirectMediaUrl(trimmed)) {
    const isHls = trimmed.split('?')[0].toLowerCase().endsWith('.m3u8');
    const filename = decodeURIComponent(trimmed.split('/').pop()?.split('?')[0] || 'Stream Video');
    const resolutions: VideoResolutionOption[] = [
      { label: 'Auto', url: trimmed },
      { label: '1080P', url: trimmed },
      { label: '720P', url: trimmed },
      { label: '480P', url: trimmed },
    ];
    return {
      videoUrl: trimmed,
      embedUrl: undefined,
      sourceType: isHls ? 'hls' : 'direct',
      title: title || filename.replace(/[-_]/g, ' '),
      resolutions,
    };
  }

  // Case 4: General web URL (treated as embed or external)
  return {
    videoUrl: trimmed,
    embedUrl: trimmed,
    sourceType: 'embed',
    title: title || 'Web Stream Video',
  };
}
