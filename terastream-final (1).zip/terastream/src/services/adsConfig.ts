import type { AdPosition } from '@/types/video';

/** How a slot is rendered:
 *  - banner:    fixed size (e.g. 728x90) inside an isolated iframe
 *  - native:    responsive (Adsterra Native Banner) inside an isolated iframe that auto-sizes
 *  - global:    script that must run on the page itself (Social Bar)
 *  - popunder:  handled by adsterraService on the Play click
 */
export type SlotMode = 'banner' | 'native' | 'global' | 'popunder';

export interface SlotInfo {
  position: AdPosition;
  id: string;
  name: string;
  dimensions: string;
  mode: SlotMode;
  where: string;
  how: string;
}

export const SLOT_CATALOG: SlotInfo[] = [
  { position: 'header_top', id: 'ad-header-banner', name: 'Header Banner', dimensions: '728x90', mode: 'banner',
    where: 'Har page par navbar ke neeche.', how: 'Adsterra → Banner 728x90. Phone ke liye "Mobile code" mein 320x50 paste karein.' },
  { position: 'above_player', id: 'ad-above-player', name: 'Above Player Banner', dimensions: '728x90', mode: 'banner',
    where: 'Watch page par video player ke upar.', how: 'Adsterra → Banner 728x90 (phone: 320x50).' },
  { position: 'below_player', id: 'ad-below-player', name: 'Below Player Banner', dimensions: '728x90', mode: 'banner',
    where: 'Watch page par video player ke neeche.', how: 'Adsterra → Banner 728x90 (phone: 320x50 ya 300x250).' },
  { position: 'watch_sidebar', id: 'ad-watch-sidebar', name: 'Sidebar Banner', dimensions: '300x250', mode: 'banner',
    where: 'Watch page ki right sidebar (phone par related videos ke upar).', how: 'Adsterra → Banner 300x250.' },
  { position: 'related_between', id: 'ad-related-between', name: 'Between Related Videos', dimensions: 'responsive', mode: 'native',
    where: 'Related / catalog videos ke beech mein.', how: 'Adsterra → Native Banner (container div + script).' },
  { position: 'native_banner', id: 'ad-native-banner', name: 'Native Banner', dimensions: 'responsive', mode: 'native',
    where: 'Home aur Browse page ke upar, intermediate page par bhi.', how: 'Adsterra → Native Banner (container div + script).' },
  { position: 'social_bar', id: 'ad-social-bar', name: 'Social Bar', dimensions: 'script', mode: 'global',
    where: 'Poori site par (floating notification style).', how: 'Adsterra → Social Bar. Sirf <script src="..."></script> paste karein.' },
  { position: 'popunder_interstitial', id: 'ad-popunder', name: 'Popunder', dimensions: 'script', mode: 'popunder',
    where: 'Video "Play" click par, 24 ghante mein sirf ek baar (admin settings mein badal sakte hain).',
    how: 'Adsterra → Popunder script, ya sirf Direct Link URL (https://...) paste karein.' },
  { position: 'sticky_bottom', id: 'ad-sticky-bottom', name: 'Sticky Bottom Banner (optional)', dimensions: '320x50', mode: 'banner',
    where: 'Screen ke neeche chipka hua, close button ke saath.', how: 'Adsterra → Banner 320x50 (mobile) ya 728x90.' },
];

export const SLOT_BY_POSITION: Record<string, SlotInfo> = Object.fromEntries(SLOT_CATALOG.map((s) => [s.position, s]));

/** Old versions shipped fake "demo ads" (purple boxes linking to adsterra.com). Treat them as empty. */
export function isPlaceholderCode(code: string | undefined): boolean {
  if (!code) return false;
  return (
    code.includes('href="https://adsterra.com"') ||
    code.includes('Adsterra Banner</span>') ||
    code.includes('Adsterra popunder slot ready') ||
    code.includes('Sponsored Partner</span>') ||
    code.includes('Enjoying this video? Bookmark this website')
  );
}

export const hasRunnableCode = (code: string | undefined): boolean => Boolean(code && code.trim() && !isPlaceholderCode(code));

export const isDirectLink = (code: string): boolean => /^https?:\/\/\S+$/i.test(code.trim());

/** width/height from an Adsterra atOptions snippet, falling back to the "728x90" dimensions field. */
export function parseAdSize(code: string, dimensions: string): { w: number; h: number } | null {
  const w = /['"]?width['"]?\s*:\s*(\d{2,4})/i.exec(code);
  const h = /['"]?height['"]?\s*:\s*(\d{2,4})/i.exec(code);
  if (w && h) return { w: Number(w[1]), h: Number(h[1]) };
  const d = /^(\d{2,4})\s*x\s*(\d{2,4})$/i.exec((dimensions || '').trim());
  return d ? { w: Number(d[1]), h: Number(d[2]) } : null;
}

export interface AdCodeReport {
  /** what we think the pasted code is */
  kind: 'empty' | 'direct-link' | 'banner' | 'native' | 'script' | 'iframe' | 'html';
  ok: boolean;
  /** short, human readable lines for the admin (Hinglish) */
  notes: string[];
}

/** Looks at what the admin pasted and says whether it fits the slot. Never blocks saving - it only advises. */
export function analyzeAdCode(code: string | undefined, mode: SlotMode): AdCodeReport {
  const c = (code || '').trim();
  if (!c) return { kind: 'empty', ok: false, notes: ['Abhi koi code nahi hai - is slot se kuch nahi dikhega.'] };
  if (isPlaceholderCode(c)) return { kind: 'html', ok: false, notes: ['Ye purana demo/placeholder code hai - asli Adsterra code paste karein.'] };

  const notes: string[] = [];
  const hasAtOptions = /atOptions/.test(c);
  const hasScriptSrc = /<script[^>]+src=/i.test(c);
  const hasContainer = /<div[^>]+id=["']container-[a-z0-9]+["']/i.test(c);
  const direct = isDirectLink(c);

  let kind: AdCodeReport['kind'] = 'html';
  if (direct) kind = 'direct-link';
  else if (hasAtOptions) kind = 'banner';
  else if (hasContainer) kind = 'native';
  else if (/<iframe/i.test(c)) kind = 'iframe';
  else if (hasScriptSrc) kind = 'script'; // Social Bar and Popunder look the same: one <script src="...">

  if (!/<script|<iframe|<div|<ins|<a /i.test(c) && !direct) notes.push('Ye HTML/script jaisa nahi lag raha - poora Adsterra snippet copy karke paste karein (<script> tags ke saath).');
  // "//host/..." is fine (Adsterra's own snippets use it); an explicit http:// is blocked on https sites
  if (/(?:src|href)=["']http:\/\//i.test(c) || /^http:\/\//i.test(c)) notes.push('Code mein "http://" link hai - https:// wala code use karein, warna https site par block ho jayega.');

  if (mode === 'banner') {
    if (kind === 'native') notes.push('Ye Native Banner ka code lag raha hai, is slot ke liye Banner (atOptions wala) code chahiye.');
    else if (kind === 'direct-link') notes.push('Direct Link banner slot mein kaam nahi karega - Popunder slot mein use karein.');
    else if (kind === 'script') notes.push('Ye Social Bar / Popunder script lag rahi hai, banner slot ke liye Banner (atOptions wala) code chahiye.');
    else if (kind === 'banner') notes.push('Banner code detect ho gaya.');
  } else if (mode === 'native') {
    if (kind === 'banner') notes.push('Ye Banner (atOptions) code hai, is slot ke liye Native Banner code (container div + script) paste karein.');
    else if (kind === 'script') notes.push('Native Banner ke code mein <div id="container-..."> bhi hona chahiye - poora snippet paste karein.');
    else if (kind === 'direct-link') notes.push('Direct Link yahan kaam nahi karega - Popunder slot mein use karein.');
    else if (kind === 'native') notes.push('Native Banner code detect ho gaya.');
  } else if (mode === 'global') {
    if (kind === 'banner' || kind === 'native') notes.push('Social Bar slot mein sirf Social Bar ka <script src="..."> chahiye.');
    else if (kind === 'direct-link') notes.push('Direct Link yahan kaam nahi karega - Popunder slot mein use karein.');
    else if (kind === 'script') notes.push('Social Bar script detect ho gayi.');
  } else if (mode === 'popunder') {
    if (kind === 'banner' || kind === 'native') notes.push('Ye banner/native code hai. Popunder ke liye Popunder script ya Direct Link URL paste karein.');
    else if (kind === 'direct-link') notes.push('Direct Link detect hua - Play click par naye tab mein khulega.');
    else if (kind === 'script') notes.push('Popunder script detect ho gayi.');
  }

  const bad = notes.some((n) => /chahiye|kaam nahi|block|nahi lag|paste karein/i.test(n));
  return { kind, ok: !bad, notes };
}
