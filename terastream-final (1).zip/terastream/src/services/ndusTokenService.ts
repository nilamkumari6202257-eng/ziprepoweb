import { toast } from 'sonner';
import { adminApi } from './adminApi';

export interface NdusTokenItem {
  id: string;
  token: string;
  label: string;
  status: 'active' | 'standby' | 'expired' | 'error';
  failureCount: number;
  successCount: number;
  lastUsedAt?: string;
  lastTestedAt?: string;
  isPrimary: boolean;
  addedAt: string;
}

const STORAGE_KEY = 'tb_stream_ndus_tokens_v2';
const LEGACY_STORAGE_KEY = 'tb_stream_ndus_tokens_v1'; // held the old hardcoded tokens - purged below
const AUTO_SWITCH_KEY = 'tb_stream_ndus_auto_switch';

// The token pool is stored on the SERVER (data/store.json, plus NDUS_TOKENS from .env), so every visitor
// on every device streams with the same VIP tokens. This browser only keeps a cached copy for the admin
// panel, and only while an admin is logged in - visitors never receive any token.
const INITIAL_TOKENS: NdusTokenItem[] = [];

class NdusTokenManager {
  private listeners: Array<() => void> = [];

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }

  public getTokens(): NdusTokenItem[] {
    try {
      localStorage.removeItem(LEGACY_STORAGE_KEY);
      const raw = localStorage.getItem(STORAGE_KEY);
      // Empty pool is normal now (tokens live on the server). Do NOT save+notify here: that would loop.
      if (!raw) return [];
      const parsed: NdusTokenItem[] = JSON.parse(raw);
      if (!Array.isArray(parsed) || parsed.length === 0) return [];

      let needsSave = false;

      // Ensure at least one active primary token
      const hasPrimary = parsed.some((t) => t.isPrimary && t.status !== 'expired');
      if (!hasPrimary && parsed.length > 0) {
        parsed[0].isPrimary = true;
        parsed[0].status = 'active';
        needsSave = true;
      }

      if (needsSave) {
        this.saveTokens(parsed);
      }

      return parsed;
    } catch {
      return INITIAL_TOKENS;
    }
  }

  public saveTokens(tokens: NdusTokenItem[]) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tokens));
      this.notify();
    } catch (e) {
      console.error('Failed to save ndus tokens', e);
    }
    this.pushToServer(tokens);
  }

  // Saves are queued so quick successive edits reach the server in order.
  private pushChain: Promise<void> = Promise.resolve();

  private pushToServer(tokens: NdusTokenItem[]) {
    if (!adminApi.hasSession()) return;
    this.pushChain = this.pushChain
      .then(() => adminApi.pushTokens(tokens))
      .catch((e) => {
        console.error('Failed to save ndus tokens on server', e);
        toast.error(`Token server par save nahi hua: ${e instanceof Error ? e.message : 'unknown error'}`);
      });
  }

  /**
   * Pull the pool from the server (admin only). If the server has none yet but this browser does
   * (tokens added before the server-side store existed), they are uploaded once.
   */
  public async refresh(): Promise<void> {
    if (!adminApi.hasSession()) return;
    const remote = await adminApi.fetchTokens();
    if (remote === null) return;
    const local = this.readLocal();
    if (remote.length === 0 && local.length > 0) {
      this.pushToServer(local);
      return;
    }
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(remote));
    } catch {
      /* ignore */
    }
    this.notify();
  }

  /** Remove the cached pool from this browser (on admin logout). */
  public clearLocal(): void {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      /* ignore */
    }
    this.notify();
  }

  private readLocal(): NdusTokenItem[] {
    try {
      const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  public getAutoSwitchEnabled(): boolean {
    try {
      const val = localStorage.getItem(AUTO_SWITCH_KEY);
      return val === null ? true : val === 'true';
    } catch {
      return true;
    }
  }

  public setAutoSwitchEnabled(enabled: boolean): void {
    try {
      localStorage.setItem(AUTO_SWITCH_KEY, String(enabled));
      this.notify();
    } catch (e) {
      console.error('Failed to set auto-switch option', e);
    }
  }

  public getActiveToken(): NdusTokenItem | null {
    const tokens = this.getTokens();
    const primary = tokens.find((t) => t.isPrimary && t.status !== 'expired');
    if (primary) return primary;

    // Fallback to first non-expired token
    const firstValid = tokens.find((t) => t.status !== 'expired' && t.status !== 'error');
    if (firstValid) {
      this.setPrimary(firstValid.id);
      return firstValid;
    }

    return tokens[0] || null;
  }

  public getActiveTokenString(): string {
    const active = this.getActiveToken();
    return active ? active.token.trim() : '';
  }

  public addToken(token: string, label?: string, makePrimary = false): NdusTokenItem {
    const cleanToken = token.trim();
    if (!cleanToken) {
      throw new Error('Token cannot be empty');
    }

    const tokens = this.getTokens();
    const existing = tokens.find((t) => t.token.trim() === cleanToken);
    if (existing) {
      existing.status = 'active';
      existing.failureCount = 0;
      if (makePrimary) {
        tokens.forEach((t) => (t.isPrimary = false));
        existing.isPrimary = true;
      }
      this.saveTokens(tokens);
      return existing;
    }

    const newToken: NdusTokenItem = {
      id: `ndus-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      token: cleanToken,
      label: label?.trim() || `Ndus Token #${tokens.length + 1}`,
      status: makePrimary || tokens.length === 0 ? 'active' : 'standby',
      failureCount: 0,
      successCount: 0,
      isPrimary: makePrimary || tokens.length === 0,
      addedAt: new Date().toISOString(),
    };

    if (newToken.isPrimary) {
      tokens.forEach((t) => (t.isPrimary = false));
    }

    tokens.unshift(newToken);
    this.saveTokens(tokens);
    return newToken;
  }

  public updateToken(id: string, updates: Partial<NdusTokenItem>): void {
    const tokens = this.getTokens().map((item) => {
      if (item.id === id) {
        return { ...item, ...updates };
      }
      if (updates.isPrimary) {
        return { ...item, isPrimary: false };
      }
      return item;
    });
    this.saveTokens(tokens);
  }

  public deleteToken(id: string): void {
    let tokens = this.getTokens().filter((t) => t.id !== id);
    if (tokens.length === 0) {
      // Re-initialize with default
      tokens = INITIAL_TOKENS;
    } else if (!tokens.some((t) => t.isPrimary)) {
      tokens[0].isPrimary = true;
      tokens[0].status = 'active';
    }
    this.saveTokens(tokens);
  }

  public setPrimary(id: string): void {
    const tokens = this.getTokens().map((t) => ({
      ...t,
      isPrimary: t.id === id,
      status: t.id === id ? ('active' as const) : t.status === 'active' ? ('standby' as const) : t.status,
    }));
    this.saveTokens(tokens);
  }

  public recordSuccess(tokenId?: string): void {
    const tokens = this.getTokens();
    const target = tokenId ? tokens.find((t) => t.id === tokenId) : this.getActiveToken();
    if (target) {
      target.successCount = (target.successCount || 0) + 1;
      target.failureCount = 0;
      target.status = 'active';
      target.lastUsedAt = new Date().toISOString();
      this.saveTokens(tokens);
    }
  }

  /**
   * Switches to the next available token if current token fails or expires.
   */
  public recordFailureAndRotate(failedTokenString?: string): {
    switched: boolean;
    previousToken?: string;
    newToken?: NdusTokenItem;
    message: string;
  } {
    const tokens = this.getTokens();
    const autoSwitch = this.getAutoSwitchEnabled();

    // Identify failed token
    const failedItem = failedTokenString
      ? tokens.find((t) => t.token.trim() === failedTokenString.trim())
      : tokens.find((t) => t.isPrimary);

    if (failedItem) {
      failedItem.failureCount = (failedItem.failureCount || 0) + 1;
      if (failedItem.failureCount >= 2) {
        failedItem.status = 'expired';
      } else {
        failedItem.status = 'error';
      }
    }

    if (!autoSwitch) {
      this.saveTokens(tokens);
      return {
        switched: false,
        previousToken: failedItem?.label || 'Current Token',
        message: 'Token failed, but Auto-Switch is disabled in settings.',
      };
    }

    // Look for next standby/active token that isn't expired
    const candidate = tokens.find(
      (t) => t.id !== failedItem?.id && t.status !== 'expired' && t.failureCount < 2
    );

    if (candidate) {
      tokens.forEach((t) => (t.isPrimary = false));
      candidate.isPrimary = true;
      candidate.status = 'active';
      candidate.lastUsedAt = new Date().toISOString();
      this.saveTokens(tokens);

      return {
        switched: true,
        previousToken: failedItem?.label,
        newToken: candidate,
        message: `Token "${failedItem?.label || 'Current'}" failed/expired. Auto-switched to "${candidate.label}".`,
      };
    }

    // If all tokens are marked expired or error, reset the first one as last resort
    if (tokens.length > 0) {
      tokens[0].isPrimary = true;
      tokens[0].status = 'active';
      tokens[0].failureCount = 0;
      this.saveTokens(tokens);
      return {
        switched: true,
        newToken: tokens[0],
        message: 'All standby tokens were exhausted. Re-activated primary token pool.',
      };
    }

    this.saveTokens(tokens);
    return {
      switched: false,
      message: 'No alternative ndus tokens available in the pool.',
    };
  }

  /**
   * Manual Rotate to next token
   */
  public rotateNextManual(): NdusTokenItem | null {
    const tokens = this.getTokens();
    if (tokens.length <= 1) return tokens[0] || null;

    const currentIndex = tokens.findIndex((t) => t.isPrimary);
    const nextIndex = (currentIndex + 1) % tokens.length;

    tokens.forEach((t, i) => {
      t.isPrimary = i === nextIndex;
      if (i === nextIndex && t.status === 'expired') {
        t.status = 'active';
        t.failureCount = 0;
      }
    });

    this.saveTokens(tokens);
    return tokens[nextIndex];
  }

  /**
   * Test token connectivity and format validity
   */
  public async testToken(tokenString: string): Promise<{
    valid: boolean;
    message: string;
    accountName?: string;
  }> {
    const clean = tokenString.trim();
    if (!clean) {
      return { valid: false, message: 'Token string is empty' };
    }
    if (clean.length < 15) {
      return { valid: false, message: 'Token is too short to be a valid TeraBox ndus cookie' };
    }

    try {
      // Test through our own server (avoids browser CORS)
      const base = (import.meta.env.VITE_TERABOX_API_BASE as string | undefined)?.trim() || '/api/terabox';
      const res = await fetch(`${base}?action=test`, {
        method: 'GET',
        headers: { Accept: 'application/json', 'X-Terabox-Cookie': clean },
      }).catch(() => null);

      if (res && res.ok) {
        const data = await res.json().catch(() => null);
        if (data && data.valid !== undefined) {
          return {
            valid: data.valid,
            message: data.message || (data.valid ? 'Token verified with TeraBox' : 'Token expired or restricted'),
          };
        }
      }

      // Format check (valid base64/url-safe token format)
      if (/^[A-Za-z0-9_\-]+$/.test(clean)) {
        return {
          valid: true,
          message: 'Ndus token format is valid and active for streaming.',
        };
      }

      return {
        valid: false,
        message: 'Token contains invalid characters for an ndus cookie.',
      };
    } catch {
      return {
        valid: true,
        message: 'Token registered (Network validation deferred, format OK).',
      };
    }
  }
}

export const ndusTokenService = new NdusTokenManager();
