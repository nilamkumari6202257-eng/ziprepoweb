import { useSyncExternalStore } from 'react';
import { storageService } from '@/services/storageService';

/** Re-renders the component whenever admin data (ads, videos, settings...) changes - locally or from the server. */
export function useStoreVersion(): number {
  return useSyncExternalStore(
    (fn) => storageService.subscribe(fn),
    () => storageService.getVersion(),
    () => 0
  );
}
