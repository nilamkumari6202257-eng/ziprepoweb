import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import Hls from 'hls.js';
import { Play, Pause, Volume2, VolumeX, Maximize, Minimize, Loader2, RefreshCw, RotateCw, Check } from 'lucide-react';
import { resolveTeraboxStreamWithAutoSwitch } from '@/services/teraboxDirectResolver';
import { Slider } from '@/components/ui/slider';
import { VideoItem, VideoResolutionOption } from '@/types/video';
import { formatDuration, extractTeraboxShareId } from '@/services/teraboxParser';
import { adsterraService } from '@/services/adsterraService';

interface TeraboxPlayerProps {
  video: VideoItem;
  isTheaterMode: boolean;
  onToggleTheater?: () => void;
  onShareClick?: () => void;
  onEnded?: () => void;
}

const SPEEDS = [1, 1.25, 1.5, 2, 0.75];

interface QualityOption {
  label: string; // 'Auto' | '1080p' | ...
  url?: string; // server-side rendition (TeraBox): swap the whole stream
  hlsLevel?: number; // native HLS level (master playlists): switch level in place
}

/** '1080P' -> '1080p' for display */
const normQuality = (l: string) => (/^\d+P$/i.test(l) ? `${l.slice(0, -1)}p` : l);

/** Remember the visitor's quality choice across videos (like YouTube). */
function loadSavedQuality(): string {
  try { return window.localStorage.getItem('playerQuality') || 'Auto'; } catch { return 'Auto'; }
}

/**
 * Clean player: just the video + a slim control bar.
 * No server / token / mirror switchers on top of the video - tokens are handled by the server.
 */
export const TeraboxPlayer: React.FC<TeraboxPlayerProps> = ({ video, isTheaterMode, onEnded }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const autoResolves = useRef(0); // stream links expire: silently re-resolve once before showing an error
  const pendingSeek = useRef<{ pos: number; wasPlaying: boolean } | null>(null); // keep position when switching quality / re-resolving

  const shareId = video.teraboxShareId || extractTeraboxShareId(video.videoUrl) || undefined;
  const isTerabox =
    video.sourceType === 'terabox' ||
    Boolean(shareId) ||
    /terabox|1024tera|nephobox/i.test(video.videoUrl || '');

  // A pasted iframe / web embed that is not TeraBox: show it as is (nothing else to resolve)
  const plainEmbedUrl = !isTerabox && video.sourceType === 'embed' ? video.embedUrl || video.videoUrl : '';

  const [streamUrl, setStreamUrl] = useState('');
  const [resolving, setResolving] = useState(!plainEmbedUrl);
  const [error, setError] = useState<string | null>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [buffering, setBuffering] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(video.duration || 0);
  const [muted, setMuted] = useState(false);
  const [speedIdx, setSpeedIdx] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);

  // ---- quality selector (server renditions for TeraBox, native HLS levels for master playlists)
  const [resolutions, setResolutions] = useState<VideoResolutionOption[]>([]);
  const [qualityLabel, setQualityLabel] = useState('Auto');
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const [hlsLevels, setHlsLevels] = useState<QualityOption[]>([]);

  // ---- video rotation (0 / 90 / 180 / 270) - rotates the video inside the player frame
  const [rotation, setRotation] = useState(0);
  const [frameAspect, setFrameAspect] = useState(16 / 9); // container w/h, for covering after a 90° turn

  // ---- resolve the stream through our server (it picks the VIP token itself)
  const resolve = useCallback(async () => {
    if (plainEmbedUrl) return;
    setResolving(true);
    setError(null);
    setStreamUrl('');
    setResolutions([]);
    setHlsLevels([]);
    const target = video.videoUrl || (shareId ? `https://1024terabox.com/s/1${shareId.replace(/^1/, '')}` : '');
    if (!target) {
      setResolving(false);
      setError('Video link missing.');
      return;
    }
    try {
      const res = await resolveTeraboxStreamWithAutoSwitch(target);
      if (res.success && res.streamUrl) {
        const opts: VideoResolutionOption[] = (res.resolutions || []).filter((r) => r.url);
        setResolutions(opts);
        // re-apply the visitor's saved quality if this video has it
        const saved = loadSavedQuality();
        const savedMatch = saved !== 'Auto' ? opts.find((o) => normQuality(o.label) === saved) : null;
        if (savedMatch && savedMatch.url && savedMatch.url !== res.streamUrl) {
          setQualityLabel(normQuality(savedMatch.label));
          setStreamUrl(savedMatch.url);
        } else {
          setQualityLabel('Auto');
          setStreamUrl(res.streamUrl);
        }
        if (res.duration && res.duration > 0) setDuration(res.duration);
      } else {
        setError(res.error || 'Video load nahi ho paya.');
      }
    } catch (e: any) {
      setError(e?.message || 'Video load nahi ho paya.');
    } finally {
      setResolving(false);
    }
  }, [video.videoUrl, shareId, plainEmbedUrl]);

  useEffect(() => {
    void resolve();
  }, [resolve]);

  // ---- attach HLS / mp4
  useEffect(() => {
    const el = videoRef.current;
    if (!el || !streamUrl) return;

    setBuffering(true);
    setHlsLevels([]);
    const isHls = /\.m3u8|action=playlist/.test(streamUrl) || video.sourceType === 'hls';

    if (isHls && Hls.isSupported()) {
      const hls = new Hls({ enableWorker: true });
      hlsRef.current = hls;
      let netRetries = 0;
      hls.loadSource(streamUrl);
      hls.attachMedia(el);
      hls.on(Hls.Events.MANIFEST_PARSED, (_e, data) => {
        setBuffering(false);
        // master playlist with several renditions? offer them as quality options (Auto = ABR)
        const levels = (data.levels || []).map((l, i) => ({
          label: l.height ? `${l.height}p` : `${Math.round((l.bitrate || 0) / 1000)} kbps`,
          hlsLevel: i,
        }));
        if (levels.length > 1) setHlsLevels(levels);
        const pend = pendingSeek.current;
        if (pend && el) {
          pendingSeek.current = null;
          if (pend.pos > 0.5) el.currentTime = pend.pos;
          if (pend.wasPlaying) el.play().catch(() => {});
        } else {
          el.play().catch(() => {});
        }
      });
      hls.on(Hls.Events.ERROR, (_, data) => {
        if (!data.fatal) return;
        const code = (data as { response?: { code?: number } }).response?.code;
        if ((code === 403 || code === 410 || code === 502) && autoResolves.current < 1) {
          // signed link / TeraBox token expired: fetch a fresh one once, without bothering the viewer
          autoResolves.current++;
          hls.destroy();
          pendingSeek.current = { pos: el.currentTime || 0, wasPlaying: !el.paused };
          void resolve();
          return;
        }
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR && netRetries < 3) {
          netRetries++;
          hls.startLoad();
        } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR && netRetries < 3) {
          netRetries++;
          hls.recoverMediaError();
        } else {
          hls.destroy();
          setBuffering(false);
          setError('Video play nahi ho paaya (network / stream error). Retry karein.');
        }
      });
    } else {
      el.src = streamUrl; // Safari / direct mp4
      el.play().catch(() => {});
    }

    return () => {
      hlsRef.current?.destroy();
      hlsRef.current = null;
    };
  }, [streamUrl, video.sourceType, resolve]);

  // ---- controls auto-hide (tap / move shows them, hidden 3s after while playing)
  const pokeControls = useCallback(() => {
    setShowControls(true);
    if (hideTimer.current) clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setShowControls(false), 3000);
  }, []);

  useEffect(() => () => {
    if (hideTimer.current) clearTimeout(hideTimer.current);
  }, []);

  const togglePlay = useCallback(() => {
    const el = videoRef.current;
    if (!el) return;
    if (el.paused) {
      adsterraService.triggerPopunder();
      el.play().catch(() => {});
    } else {
      el.pause();
    }
  }, []);

  const toggleMute = () => {
    const el = videoRef.current;
    if (!el) return;
    el.muted = !el.muted;
    setMuted(el.muted);
  };

  const cycleSpeed = () => {
    const next = (speedIdx + 1) % SPEEDS.length;
    setSpeedIdx(next);
    if (videoRef.current) videoRef.current.playbackRate = SPEEDS[next];
  };

  // ---- quality menu options: server renditions first, then native HLS levels, else just Auto
  const qualityOptions: QualityOption[] = useMemo(() => {
    const list: QualityOption[] = [];
    const seen = new Set<string>();
    const push = (o: QualityOption) => {
      if (!seen.has(o.label)) { seen.add(o.label); list.push(o); }
    };
    if (resolutions.length > 1) {
      // TeraBox: the server probed every rendition for us
      resolutions.forEach((r) => push({ label: normQuality(r.label), url: r.url }));
    } else if (hlsLevels.length > 1) {
      // master playlist (e.g. direct .m3u8): switch hls.js levels in place, Auto = ABR
      push({ label: 'Auto', hlsLevel: -1 });
      hlsLevels.forEach(push);
    }
    if (list.length === 0) push({ label: 'Auto' }); // single mp4 / one rendition
    return list;
  }, [resolutions, hlsLevels]);

  const switchQuality = (opt: QualityOption) => {
    setShowQualityMenu(false);
    pokeControls();
    if (opt.label === qualityLabel) return;
    setQualityLabel(opt.label);
    try { window.localStorage.setItem('playerQuality', opt.label); } catch { /* ignore */ }
    if (opt.url && opt.url !== streamUrl) {
      // TeraBox rendition: swap the stream, keep position + playing state
      const el = videoRef.current;
      pendingSeek.current = { pos: el?.currentTime || 0, wasPlaying: el ? !el.paused : true };
      setStreamUrl(opt.url);
    } else if (opt.hlsLevel !== undefined && hlsRef.current) {
      // native HLS level: -1 = auto (ABR), else the level index
      hlsRef.current.currentLevel = opt.hlsLevel;
    }
  };

  const cycleRotation = () => {
    setRotation((r) => (r + 90) % 360);
    pokeControls();
  };

  // rotation 90/270: contain + scale(frameAspect) keeps the frame fully covered after the turn
  const isSideways = rotation === 90 || rotation === 270;
  const videoStyle =
    rotation !== 0
      ? { transform: `rotate(${rotation}deg)${isSideways ? ` scale(${frameAspect.toFixed(4)})` : ''}` }
      : undefined;

  const toggleFullscreen = () => {
    const box = containerRef.current;
    const el = videoRef.current as (HTMLVideoElement & { webkitEnterFullscreen?: () => void }) | null;
    if (document.fullscreenElement) {
      void document.exitFullscreen();
      return;
    }
    if (box?.requestFullscreen) box.requestFullscreen().catch(() => el?.webkitEnterFullscreen?.());
    else el?.webkitEnterFullscreen?.(); // iPhone Safari
  };

  useEffect(() => {
    const onFs = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onFs);
    return () => document.removeEventListener('fullscreenchange', onFs);
  }, []);

  // keep the container aspect ratio fresh (normal / theater / fullscreen all differ)
  useEffect(() => {
    const box = containerRef.current;
    if (!box || typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(() => {
      const w = box.clientWidth;
      const h = box.clientHeight;
      if (w > 0 && h > 0) setFrameAspect(w / h);
    });
    ro.observe(box);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) return;
      const el = videoRef.current;
      if (!el) return;
      const k = e.key.toLowerCase();
      if (k === ' ' || k === 'k') { e.preventDefault(); togglePlay(); }
      else if (k === 'f') { e.preventDefault(); toggleFullscreen(); }
      else if (k === 'm') { e.preventDefault(); toggleMute(); }
      else if (k === 'arrowright') el.currentTime = Math.min(el.currentTime + 5, el.duration || el.currentTime + 5);
      else if (k === 'arrowleft') el.currentTime = Math.max(el.currentTime - 5, 0);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  // player always stays 16:9 (21:9 in theater mode) — the video object-cover fills the whole frame
  const frame = `relative w-full overflow-hidden bg-black rounded-2xl md:rounded-3xl border border-white/10 ${
    isTheaterMode ? 'aspect-video md:aspect-[21/9] md:max-h-[82vh]' : 'aspect-video'
  }`;

  // ---------------------------------------------------------------- plain embed (non-TeraBox)
  if (plainEmbedUrl) {
    return (
      <div className={frame}>
        <iframe
          src={plainEmbedUrl}
          title={video.title}
          className="absolute inset-0 h-full w-full border-0"
          allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
          allowFullScreen
        />
      </div>
    );
  }

  const controlsVisible = showControls || !isPlaying || showQualityMenu;

  return (
    <div
      ref={containerRef}
      className={`${frame} select-none`}
      onMouseMove={pokeControls}
      // first tap/click on the player (Play, or tapping the video when autoplay already started): popunder, capped per visitor
      onPointerDownCapture={() => {
        adsterraService.triggerPopunder();
      }}
    >
      <video
        ref={videoRef}
        playsInline
        poster={video.thumbnail}
        style={videoStyle}
        className={`absolute inset-0 h-full w-full bg-black ${isSideways ? 'object-contain' : 'object-cover'}`}
        onClick={() => {
          pokeControls();
          togglePlay();
        }}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onPlaying={() => {
          setBuffering(false);
          setIsPlaying(true);
          pokeControls();
        }}
        onWaiting={() => setBuffering(true)}
        onLoadedMetadata={(e) => {
          const el = e.currentTarget;
          const d = el.duration;
          if (Number.isFinite(d) && d > 0) setDuration(d);
          // direct mp4 path: resume position after a quality/stream swap
          const pend = pendingSeek.current;
          if (pend) {
            pendingSeek.current = null;
            if (pend.pos > 0.5) el.currentTime = pend.pos;
            if (pend.wasPlaying) el.play().catch(() => {});
          }
          setBuffering(false);
        }}
        onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
        onEnded={() => {
          setIsPlaying(false);
          onEnded?.();
        }}
        onError={() => {
          if (streamUrl) setError('Video chalane mein problem aayi.');
        }}
      />

      {/* big play button (only when paused and nothing else is showing) */}
      {!isPlaying && !resolving && !buffering && !error && streamUrl && (
        <button
          type="button"
          onClick={togglePlay}
          aria-label="Play"
          className="absolute inset-0 flex items-center justify-center bg-black/25"
        >
          <span className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/90 text-white shadow-lg md:h-20 md:w-20">
            <Play className="ml-0.5 h-7 w-7 fill-white md:h-10 md:w-10" />
          </span>
        </button>
      )}

      {/* loading: just a spinner */}
      {(resolving || (buffering && !error)) && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/40">
          <Loader2 className="h-9 w-9 animate-spin text-white/90" />
        </div>
      )}

      {/* error: one message, one button */}
      {error && !resolving && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-black/85 p-4 text-center">
          <p className="text-sm font-semibold text-white/90">Video abhi load nahi ho raha.</p>
          <p className="max-w-md text-xs leading-relaxed text-white/60">{error}</p>
          <button
            type="button"
            onClick={() => {
              autoResolves.current = 0;
              void resolve();
            }}
            className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-xs font-semibold text-white"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Retry
          </button>
        </div>
      )}

      {/* quality menu (Auto / 1080p / 720p / ...) */}
      {showQualityMenu && streamUrl && !error && (
        <>
          <div className="absolute inset-0 z-20" onClick={(e) => { e.stopPropagation(); setShowQualityMenu(false); }} />
          <div
            className="absolute bottom-[4.5rem] right-2 z-30 w-36 overflow-hidden rounded-xl border border-white/10 bg-[#15151f]/95 py-1 shadow-2xl backdrop-blur md:right-3"
            onClick={(e) => e.stopPropagation()}
          >
            <p className="px-3 pb-1 pt-1.5 text-[10px] font-semibold uppercase tracking-wider text-white/40">Quality</p>
            <div className="max-h-56 overflow-y-auto">
              {qualityOptions.map((opt) => (
                <button
                  type="button"
                  key={opt.label}
                  onClick={() => switchQuality(opt)}
                  className={`flex w-full items-center justify-between px-3 py-1.5 text-left text-[11px] font-medium transition-colors hover:bg-white/10 active:bg-white/15 ${
                    opt.label === qualityLabel ? 'text-white' : 'text-white/70'
                  }`}
                >
                  <span>{opt.label}</span>
                  {opt.label === qualityLabel && <Check className="h-3.5 w-3.5 text-primary" />}
                </button>
              ))}
            </div>
          </div>
        </>
      )}

      {/* slim control bar */}
      {streamUrl && !error && (
        <div
          className={`absolute inset-x-0 bottom-0 z-10 bg-gradient-to-t from-black/85 to-transparent px-2 pb-1.5 pt-6 transition-opacity duration-200 md:px-3 md:pb-2 ${
            controlsVisible ? 'opacity-100' : 'pointer-events-none opacity-0'
          }`}
          onClick={(e) => e.stopPropagation()}
        >
          <Slider
            value={[Math.min(currentTime, duration || 0)]}
            min={0}
            max={duration > 0 ? duration : 1}
            step={0.1}
            onValueChange={(v) => {
              if (videoRef.current) videoRef.current.currentTime = v[0];
              setCurrentTime(v[0]);
              pokeControls();
            }}
            className="w-full py-1"
          />
          <div className="mt-0.5 flex items-center justify-between text-white">
            <div className="flex items-center gap-1">
              <button type="button" onClick={togglePlay} aria-label={isPlaying ? 'Pause' : 'Play'} className="flex h-9 w-9 items-center justify-center rounded-full active:bg-white/20">
                {isPlaying ? <Pause className="h-4 w-4 fill-white" /> : <Play className="ml-0.5 h-4 w-4 fill-white" />}
              </button>
              <span className="font-mono text-[11px] text-white/85">
                {formatDuration(currentTime)} / {formatDuration(duration)}
              </span>
            </div>
            <div className="flex items-center gap-0.5">
              <button type="button" onClick={cycleSpeed} className="h-9 min-w-9 rounded-full px-2 text-[11px] font-semibold active:bg-white/20">
                {SPEEDS[speedIdx]}x
              </button>
              <button
                type="button"
                onClick={() => { setShowQualityMenu((s) => !s); pokeControls(); }}
                aria-label="Quality"
                title="Quality select karein (Auto / 1080p / 720p / ...)"
                className="h-9 min-w-9 rounded-full px-2 text-[11px] font-semibold active:bg-white/20"
              >
                {qualityLabel}
              </button>
              <button
                type="button"
                onClick={cycleRotation}
                aria-label="Rotate"
                title="Video rotate karein (90°)"
                className="flex h-9 w-9 items-center justify-center rounded-full active:bg-white/20 text-white"
              >
                <RotateCw className="h-4 w-4" />
              </button>
              <button type="button" onClick={toggleMute} aria-label="Mute" className="flex h-9 w-9 items-center justify-center rounded-full active:bg-white/20">
                {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </button>
              <button type="button" onClick={toggleFullscreen} aria-label="Fullscreen" className="flex h-9 w-9 items-center justify-center rounded-full active:bg-white/20">
                {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
