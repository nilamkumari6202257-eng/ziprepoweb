import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { VideoItem } from '@/types/video';
import { Play, Eye, ThumbsUp, Bookmark, Share2, Flame, Clock } from 'lucide-react';
import { storageService } from '@/services/storageService';
import { ShareModal } from '@/components/common/ShareModal';
import { toast } from 'sonner';

interface VideoCardProps {
  video: VideoItem;
  onWatchlistChange?: () => void;
  variant?: 'standard' | 'compact' | 'featured';
}

export const VideoCard: React.FC<VideoCardProps> = ({
  video,
  onWatchlistChange,
  variant = 'standard',
}) => {
  const [isSaved, setIsSaved] = useState(() => {
    const interactions = storageService.getUserInteractions();
    return interactions.watchlist.includes(video.id);
  });
  const [shareOpen, setShareOpen] = useState(false);

  const handleToggleWatchlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const saved = storageService.toggleWatchlist(video.id);
    setIsSaved(saved);
    toast.success(saved ? 'Added to your Watchlist!' : 'Removed from Watchlist');
    if (onWatchlistChange) onWatchlistChange();
  };

  const handleShareClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setShareOpen(true);
  };

  if (variant === 'compact') {
    return (
      <>
        <div className="group relative flex gap-3 p-2 rounded-2xl bg-white/[0.02] hover:bg-white/[0.05] border border-white/[0.05] hover:border-violet-400/30 transition-all duration-300">
          <Link
            to={`/watch/${video.slug || video.id}`}
            className="relative h-[72px] w-32 shrink-0 overflow-hidden rounded-xl bg-muted"
          >
            <img
              src={video.thumbnail}
              alt={video.title}
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src =
                  'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1280&auto=format&fit=crop&q=80';
              }}
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            {video.durationFormatted && (
              <span className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded-md bg-black/85 font-mono text-[10px] font-medium text-white">
                {video.durationFormatted}
              </span>
            )}
            <div className="absolute inset-0 flex items-center justify-center bg-black/45 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 shadow-lg shadow-violet-500/40 scale-75 group-hover:scale-100 transition-transform duration-300">
                <Play className="h-3.5 w-3.5 fill-white text-white" />
              </div>
            </div>
          </Link>

          <div className="flex-1 min-w-0 flex flex-col justify-between py-0.5">
            <div>
              <Link to={`/watch/${video.slug || video.id}`}>
                <h4 className="text-xs font-semibold text-foreground line-clamp-2 leading-snug break-words group-hover:text-violet-300 transition-colors">
                  {video.title}
                </h4>
              </Link>
              <div className="flex items-center gap-1.5 mt-1.5 text-[11px] text-muted-foreground">
                <span className="capitalize">{video.category}</span>
                <span className="text-white/20">•</span>
                <span className="inline-flex items-center gap-1">
                  <Eye className="h-3 w-3" />
                  {video.views.toLocaleString()}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-0.5 mt-1 -ml-1">
              <button
                onClick={handleShareClick}
                className="p-1.5 rounded-lg text-muted-foreground hover:text-white hover:bg-white/[0.07] transition-colors"
                title="Share video"
              >
                <Share2 className="h-3.5 w-3.5" />
              </button>
              <button
                onClick={handleToggleWatchlist}
                className={`p-1.5 rounded-lg transition-colors ${
                  isSaved
                    ? 'text-violet-300 bg-violet-500/15'
                    : 'text-muted-foreground hover:text-white hover:bg-white/[0.07]'
                }`}
                title="Save to watchlist"
              >
                <Bookmark className={`h-3.5 w-3.5 ${isSaved ? 'fill-current' : ''}`} />
              </button>
            </div>
          </div>
        </div>

        <ShareModal video={video} isOpen={shareOpen} onOpenChange={setShareOpen} />
      </>
    );
  }

  return (
    <>
      <div className="group relative flex flex-col overflow-hidden rounded-2xl border border-white/[0.07] bg-card/60 hover:border-violet-400/40 hover:bg-card transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-violet-950/40">
        {/* Thumbnail View */}
        <Link
          to={`/watch/${video.slug || video.id}`}
          className="relative aspect-video w-full overflow-hidden bg-muted"
        >
          <img
            src={video.thumbnail}
            alt={video.title}
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src =
                'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1280&auto=format&fit=crop&q=80';
            }}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.06]"
          />

          {/* Bottom gradient legibility overlay */}
          <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-black/55 to-transparent pointer-events-none" />

          {/* Badges Overlay */}
          <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-black/60 text-white backdrop-blur-md border border-white/15">
              {video.category}
            </span>
            {video.trending && (
              <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-gradient-to-r from-amber-500 to-rose-500 text-white shadow-md shadow-rose-500/30">
                <Flame className="h-2.5 w-2.5" /> Trending
              </span>
            )}
          </div>

          {/* Duration Pill */}
          {video.durationFormatted && (
            <span className="absolute bottom-2.5 right-2.5 flex items-center gap-1 px-2 py-0.5 rounded-md bg-black/85 font-mono text-[11px] font-medium text-white backdrop-blur-sm">
              <Clock className="h-3 w-3" />
              {video.durationFormatted}
            </span>
          )}

          {/* Hover Play Button Overlay */}
          <div className="absolute inset-0 flex items-center justify-center bg-black/35 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white shadow-xl shadow-violet-500/50 scale-75 group-hover:scale-100 transition-transform duration-300">
              <Play className="h-5 w-5 ml-0.5 fill-white" />
            </div>
          </div>
        </Link>

        {/* Video Card Body */}
        <div className="p-3.5 flex flex-col flex-1 justify-between">
          <div>
            <Link to={`/watch/${video.slug || video.id}`}>
              <h3 className="text-sm font-bold text-foreground line-clamp-2 leading-snug break-words group-hover:text-violet-300 transition-colors">
                {video.title}
              </h3>
            </Link>
            <p className="mt-1 text-xs text-muted-foreground line-clamp-1">
              {video.description || 'Watch in high definition with smooth playback.'}
            </p>
          </div>

          {/* Footer Metrics & Actions */}
          <div className="mt-3.5 pt-3 border-t border-white/[0.06] flex items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1 font-medium">
                <Eye className="h-3.5 w-3.5 text-muted-foreground/70" />
                {video.views.toLocaleString()}
              </span>
              <span className="flex items-center gap-1 font-medium">
                <ThumbsUp className="h-3.5 w-3.5 text-muted-foreground/70" />
                {video.likes.toLocaleString()}
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={handleShareClick}
                className="flex h-7 w-7 items-center justify-center rounded-lg bg-white/[0.05] hover:bg-violet-500/20 hover:text-violet-200 text-muted-foreground hover:text-white transition-colors"
                title="Share video page"
              >
                <Share2 className="h-3.5 w-3.5" />
              </button>
              <button
                onClick={handleToggleWatchlist}
                className={`flex h-7 w-7 items-center justify-center rounded-lg transition-colors ${
                  isSaved
                    ? 'bg-violet-500/20 text-violet-300 border border-violet-400/30'
                    : 'bg-white/[0.05] text-muted-foreground hover:bg-violet-500/20 hover:text-white'
                }`}
                title={isSaved ? 'Remove from Watchlist' : 'Save to Watchlist'}
              >
                <Bookmark className={`h-3.5 w-3.5 ${isSaved ? 'fill-current' : ''}`} />
              </button>
            </div>
          </div>
        </div>
      </div>

      <ShareModal video={video} isOpen={shareOpen} onOpenChange={setShareOpen} />
    </>
  );
};
