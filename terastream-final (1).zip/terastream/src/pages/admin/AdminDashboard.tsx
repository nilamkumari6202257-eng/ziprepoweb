import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { storageService } from '@/services/storageService';
import { SLOT_BY_POSITION, analyzeAdCode, hasRunnableCode, parseAdSize } from '@/services/adsConfig';
import { AdFrame } from '@/components/ads/AdSlot';
import { StreamDiagnose } from '@/components/admin/StreamDiagnose';
import { ndusTokenService } from '@/services/ndusTokenService';
import {
  parseVideoSource,
  extractTeraboxShareId,
  formatDuration,
  DEFAULT_ADAPTIVE_STREAMS,
} from '@/services/teraboxParser';
import { ThumbnailUploader } from '@/components/common/ThumbnailUploader';
import { NdusTokenManager } from '@/components/admin/NdusTokenManager';
import {
  VideoItem,
  CategoryItem,
  AdUnit,
  SiteSettings,
  AdPosition,
} from '@/types/video';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Shield,
  Film,
  Plus,
  Trash2,
  Edit,
  Eye,
  Layers,
  Sparkles,
  Settings,
  DollarSign,
  TrendingUp,
  Link as LinkIcon,
  Upload,
  CheckCircle,
  Copy,
  ExternalLink,
  Lock,
  LogOut,
  RefreshCw,
  Search,
  Key,
} from 'lucide-react';
import { toast } from 'sonner';

export const AdminDashboard: React.FC = () => {
  // Auth state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() =>
    storageService.isAdminAuthenticated()
  );
  const [passwordInput, setPasswordInput] = useState('');

  // Active tab
  const [activeTab, setActiveTab] = useState('overview');

  // Data states
  const [videos, setVideos] = useState<VideoItem[]>([]);
  const [categories, setCategories] = useState<CategoryItem[]>([]);
  const [ads, setAds] = useState<AdUnit[]>([]);
  const [settings, setSettings] = useState<SiteSettings>(storageService.getSettings());

  // Video Search & Filter in Admin
  const [videoSearch, setVideoSearch] = useState('');
  const [videoCategoryFilter, setVideoCategoryFilter] = useState('all');

  // Video Modal (Add / Edit)
  const [videoModalOpen, setVideoModalOpen] = useState(false);
  const [editingVideo, setEditingVideo] = useState<VideoItem | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    description: '',
    thumbnail: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1280&auto=format&fit=crop&q=80',
    videoUrl: '',
    embedUrl: '',
    directStreamUrl: '',
    sourceType: 'terabox' as VideoItem['sourceType'],
    category: 'movies',
    tags: '',
    duration: 180,
    featured: false,
    trending: false,
    status: 'published' as VideoItem['status'],
  });

  // Bulk Import state
  const [bulkInput, setBulkInput] = useState('');
  const [bulkCategory, setBulkCategory] = useState('movies');
  const [bulkThumbnail, setBulkThumbnail] = useState(
    'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1280&auto=format&fit=crop&q=80'
  );
  const [bulkStatus, setBulkStatus] = useState<string | null>(null);

  // Category Modal
  const [categoryModalOpen, setCategoryModalOpen] = useState(false);
  const [categoryForm, setCategoryForm] = useState({ id: '', name: '', slug: '', description: '' });

  // Ad Edit Modal
  const [adModalOpen, setAdModalOpen] = useState(false);
  const [editingAd, setEditingAd] = useState<AdUnit | null>(null);
  const [adPreview, setAdPreview] = useState<{ code: string; n: number } | null>(null);

  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = () => {
    setVideos(storageService.getVideos());
    setCategories(storageService.getCategories());
    setAds(storageService.getAds());
    setSettings(storageService.getSettings());
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // Password is verified by the server (ADMIN_PASSWORD in .env)
      await storageService.adminLogin(passwordInput);
      await ndusTokenService.refresh();
      loadAllData();
      setIsAuthenticated(true);
      toast.success('Admin authorized successfully!');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Login failed');
    }
  };

  const handleLogout = () => {
    storageService.adminLogout();
    ndusTokenService.clearLocal();
    setIsAuthenticated(false);
    toast.success('Logged out from Admin');
  };

  // Video Parser Helper when user pastes URL in Add Video modal
  const handleUrlChange = (url: string) => {
    const parsed = parseVideoSource(url);
    setFormData((prev) => ({
      ...prev,
      videoUrl: url,
      embedUrl: parsed.embedUrl || '',
      sourceType: parsed.sourceType || 'terabox',
      title: prev.title || parsed.title || '',
    }));
  };

  const handleOpenAddVideo = () => {
    setEditingVideo(null);
    setFormData({
      title: '',
      slug: '',
      description: '',
      thumbnail: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1280&auto=format&fit=crop&q=80',
      videoUrl: '',
      embedUrl: '',
      directStreamUrl: '',
      sourceType: 'terabox',
      category: categories[0]?.slug || 'movies',
      tags: 'TeraBox, HD Stream',
      duration: 180,
      featured: false,
      trending: false,
      status: 'published',
    });
    setVideoModalOpen(true);
  };

  const handleOpenEditVideo = (v: VideoItem) => {
    setEditingVideo(v);
    setFormData({
      title: v.title,
      slug: v.slug,
      description: v.description,
      thumbnail: v.thumbnail,
      videoUrl: v.videoUrl,
      embedUrl: v.embedUrl || '',
      directStreamUrl: v.directStreamUrl || '',
      sourceType: v.sourceType,
      category: v.category,
      tags: v.tags.join(', '),
      duration: v.duration,
      featured: v.featured,
      trending: v.trending,
      status: v.status,
    });
    setVideoModalOpen(true);
  };

  const handleSaveVideo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.videoUrl.trim()) {
      toast.error('Please enter Title and Video/Embed URL');
      return;
    }

    const shareId = extractTeraboxShareId(formData.videoUrl) || undefined;
    const slug =
      formData.slug.trim() ||
      formData.title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');

    const videoItem: VideoItem = {
      id: editingVideo ? editingVideo.id : `vid-${Date.now()}`,
      title: formData.title.trim(),
      slug,
      description: formData.description.trim(),
      thumbnail: formData.thumbnail.trim(),
      videoUrl: formData.videoUrl.trim(),
      embedUrl: formData.embedUrl.trim() || undefined,
      directStreamUrl: formData.directStreamUrl.trim() || undefined,
      sourceType: formData.sourceType,
      teraboxShareId: shareId,
      category: formData.category,
      tags: formData.tags.split(',').map((t) => t.trim()).filter(Boolean),
      duration: Number(formData.duration) || 180,
      views: editingVideo ? editingVideo.views : 0,
      likes: editingVideo ? editingVideo.likes : 0,
      dislikes: editingVideo ? editingVideo.dislikes : 0,
      featured: formData.featured,
      trending: formData.trending,
      status: formData.status,
      createdAt: editingVideo ? editingVideo.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      resolutions: DEFAULT_ADAPTIVE_STREAMS,
    };

    storageService.saveVideo(videoItem);
    setVideos(storageService.getVideos());
    setVideoModalOpen(false);
    toast.success(editingVideo ? 'Video updated successfully!' : 'Video added successfully!');
  };

  const handleDeleteVideo = (id: string) => {
    if (confirm('Are you sure you want to delete this video?')) {
      storageService.deleteVideo(id);
      setVideos(storageService.getVideos());
      toast.success('Video deleted');
    }
  };

  // Bulk Import
  const handleBulkImport = () => {
    if (!bulkInput.trim()) {
      toast.error('Please paste one or more video links');
      return;
    }

    const lines = bulkInput
      .split('\n')
      .map((l) => l.trim())
      .filter(Boolean);
    let importedCount = 0;

    lines.forEach((line, idx) => {
      const parsed = parseVideoSource(line);
      const video: VideoItem = {
        id: `bulk-${Date.now()}-${idx}`,
        title: parsed.title || `Imported Video Stream #${idx + 1}`,
        slug: `imported-stream-${Date.now()}-${idx}`,
        description: 'Imported via TeraBox Bulk Manager.',
        thumbnail: bulkThumbnail || 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1280&auto=format&fit=crop&q=80',
        videoUrl: parsed.videoUrl || line,
        embedUrl: parsed.embedUrl,
        sourceType: parsed.sourceType || 'terabox',
        teraboxShareId: parsed.teraboxShareId,
        category: bulkCategory,
        tags: ['TeraBox', 'BulkImport'],
        duration: 200,
        views: 0,
        likes: 0,
        dislikes: 0,
        featured: false,
        trending: false,
        status: 'published',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        resolutions: DEFAULT_ADAPTIVE_STREAMS,
      };
      storageService.saveVideo(video);
      importedCount++;
    });

    setVideos(storageService.getVideos());
    setBulkInput('');
    setBulkStatus(`Successfully imported ${importedCount} TeraBox video links!`);
    toast.success(`Imported ${importedCount} videos!`);
  };

  // Category Actions
  const handleSaveCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!categoryForm.name.trim()) return;

    const slug =
      categoryForm.slug.trim() ||
      categoryForm.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const newCat: CategoryItem = {
      id: categoryForm.id || `cat-${Date.now()}`,
      name: categoryForm.name.trim(),
      slug,
      description: categoryForm.description.trim(),
    };
    storageService.saveCategory(newCat);
    setCategories(storageService.getCategories());
    setCategoryModalOpen(false);
    toast.success('Category saved');
  };

  const handleDeleteCategory = (id: string) => {
    if (confirm('Delete this category?')) {
      storageService.deleteCategory(id);
      setCategories(storageService.getCategories());
      toast.success('Category deleted');
    }
  };

  // Ad Actions
  const handleToggleAd = (ad: AdUnit) => {
    const updated = { ...ad, enabled: !ad.enabled };
    storageService.saveAd(updated);
    setAds(storageService.getAds());
    toast.success(`${ad.name} ${updated.enabled ? 'Enabled' : 'Disabled'}`);
  };

  const handleSaveAd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAd) return;
    const toSave: AdUnit = { ...editingAd, code: editingAd.code.trim(), mobileCode: (editingAd.mobileCode || '').trim() };
    // nothing to show -> never leave a slot "enabled" with empty code
    if (!hasRunnableCode(toSave.code) && !hasRunnableCode(toSave.mobileCode)) toSave.enabled = false;
    storageService.saveAd(toSave);
    setAds(storageService.getAds());
    setAdModalOpen(false);
    setAdPreview(null);
    const report = analyzeAdCode(toSave.code, SLOT_BY_POSITION[toSave.position]?.mode ?? 'banner');
    if (hasRunnableCode(toSave.code) && !report.ok) toast.warning(`${toSave.name}: save ho gaya, par code check karein - ${report.notes[0] || ''}`);
  };

  // Settings Actions
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    storageService.saveSettings(settings);
    toast.success('Site settings saved successfully!');
  };

  // Filtered videos in table
  const filteredVideos = videos.filter((v) => {
    if (videoCategoryFilter !== 'all' && v.category !== videoCategoryFilter) return false;
    if (videoSearch.trim()) {
      const q = videoSearch.toLowerCase();
      return (
        v.title.toLowerCase().includes(q) ||
        (v.teraboxShareId && v.teraboxShareId.toLowerCase().includes(q))
      );
    }
    return true;
  });

  // Calculate overview metrics
  const totalViews = videos.reduce((acc, v) => acc + (v.views || 0), 0);
  const totalLikes = videos.reduce((acc, v) => acc + (v.likes || 0), 0);
  const activeAdsCount = ads.filter((a) => a.enabled).length;

  if (!isAuthenticated) {
    return (
      <MainLayout showTopAd={false} hideAds>
        <div className="flex min-h-[60vh] items-center justify-center py-12">
          <div className="w-full max-w-md p-6 md:p-8 rounded-3xl border border-white/10 bg-white/[0.04] backdrop-blur-xl shadow-2xl">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/20 text-primary mx-auto mb-4">
              <Shield className="h-6 w-6" />
            </div>
            <h2 className="text-xl font-bold text-center text-white mb-1">
              Admin Access Authentication
            </h2>
            <p className="text-xs text-center text-muted-foreground mb-6">
              Manage TeraBox streams, video catalog, Adsterra monetization, and site settings.
            </p>

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-foreground/80 mb-1.5 block">
                  Admin Passcode
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="password"
                    placeholder="Enter admin password"
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    className="h-10 pl-9 bg-background/50 border-border text-xs"
                  />
                </div>
              </div>
              <Button type="submit" className="w-full h-10 rounded-xl bg-primary hover:bg-primary/90 text-white font-bold text-xs">
                Unlock Admin Panel
              </Button>
            </form>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout showTopAd={false} hideAds>
      {/* Admin Header */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/20 text-primary">
              <Shield className="h-4 w-4" />
            </div>
            <h1 className="text-xl md:text-2xl font-black text-white">
              Platform Administration & Content Manager
            </h1>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            Full control over TeraBox video embeds, bulk link import, Adsterra banners, and platform configurations.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            onClick={handleOpenAddVideo}
            className="h-9 px-4 rounded-xl bg-primary hover:bg-primary/90 text-white font-bold text-xs gap-1.5 shadow-md shadow-primary/20"
          >
            <Plus className="h-4 w-4" /> Add / Embed TeraBox Video
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleLogout}
            className="h-9 px-3 rounded-xl border-white/10 text-xs text-muted-foreground hover:text-white"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-2 sm:grid-cols-7 mb-6 bg-white/[0.04] p-1 rounded-2xl border border-white/10">
          <TabsTrigger value="overview" className="text-xs font-semibold">Overview</TabsTrigger>
          <TabsTrigger value="videos" className="text-xs font-semibold">Videos ({videos.length})</TabsTrigger>
          <TabsTrigger value="tokens" className="text-xs font-semibold flex items-center gap-1">
            <Key className="h-3.5 w-3.5 text-primary" /> Tokens
          </TabsTrigger>
          <TabsTrigger value="bulk" className="text-xs font-semibold">Bulk Import</TabsTrigger>
          <TabsTrigger value="categories" className="text-xs font-semibold">Categories ({categories.length})</TabsTrigger>
          <TabsTrigger value="ads" className="text-xs font-semibold">Ads & Monetization</TabsTrigger>
          <TabsTrigger value="settings" className="text-xs font-semibold">Settings</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Metrics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur-md">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-muted-foreground">Total Videos</span>
                <Film className="h-4 w-4 text-primary" />
              </div>
              <div className="text-2xl font-black text-white">{videos.length}</div>
              <div className="text-[11px] text-muted-foreground mt-1">Available for streaming</div>
            </div>

            <div className="p-5 rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur-md">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-muted-foreground">Total Views</span>
                <Eye className="h-4 w-4 text-cyan-400" />
              </div>
              <div className="text-2xl font-black text-white">{totalViews.toLocaleString()}</div>
              <div className="text-[11px] text-muted-foreground mt-1">Video stream impressions</div>
            </div>

            <div className="p-5 rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur-md">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-muted-foreground">Active Ad Slots</span>
                <DollarSign className="h-4 w-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-white">{activeAdsCount} / {ads.length}</div>
              <div className="text-[11px] text-muted-foreground mt-1">Adsterra & custom units</div>
            </div>

            <div className="p-5 rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur-md">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-muted-foreground">User Likes</span>
                <Sparkles className="h-4 w-4 text-amber-400" />
              </div>
              <div className="text-2xl font-black text-white">{totalLikes.toLocaleString()}</div>
              <div className="text-[11px] text-muted-foreground mt-1">Engagement feedback</div>
            </div>
          </div>

          {/* Quick Actions Card */}
          <div className="p-6 rounded-3xl border border-white/10 bg-white/[0.03] backdrop-blur-md">
            <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              Quick Content Management Actions
            </h3>
            <p className="text-xs text-muted-foreground mb-4">
              Add new TeraBox links, configure monetization banners, or bulk import video collections.
            </p>
            <div className="flex flex-wrap items-center gap-3">
              <Button onClick={handleOpenAddVideo} className="bg-primary hover:bg-primary/90 text-primary-foreground text-xs h-9 font-semibold">
                <Plus className="h-4 w-4 mr-1.5" /> Add Single TeraBox Video
              </Button>
              <Button onClick={() => setActiveTab('bulk')} variant="ghost" className="border border-white/10 hover:bg-white/10 text-xs h-9">
                <Upload className="h-4 w-4 mr-1.5" /> Multi-Link Bulk Importer
              </Button>
              <Button onClick={() => setActiveTab('ads')} variant="ghost" className="border border-white/10 hover:bg-white/10 text-xs h-9">
                <DollarSign className="h-4 w-4 mr-1.5" /> Configure Adsterra Ads
              </Button>
              <Button onClick={() => setActiveTab('tokens')} variant="ghost" className="border border-primary/30 hover:bg-primary/10 text-primary text-xs h-9 font-semibold">
                <Key className="h-4 w-4 mr-1.5" /> Manage Ndus VIP Tokens
              </Button>
              <Link to="/browse">
                <Button variant="ghost" className="text-xs h-9 text-muted-foreground hover:text-foreground">
                  Preview Live Catalog <ExternalLink className="h-3.5 w-3.5 ml-1.5" />
                </Button>
              </Link>
            </div>
          </div>

          {/* Recent Videos Overview */}
          <div className="p-6 rounded-3xl border border-white/10 bg-white/[0.03] backdrop-blur-md">
            <h3 className="text-sm font-bold text-white mb-4">Latest Added Videos</h3>
            <div className="space-y-2">
              {videos.slice(0, 5).map((v) => (
                <div key={v.id} className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.02] border border-white/5">
                  <div className="flex items-center gap-3 min-w-0">
                    <img src={v.thumbnail} alt={v.title} className="h-10 w-16 object-cover rounded-lg shrink-0" />
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white truncate">{v.title}</div>
                      <div className="text-[11px] text-muted-foreground flex items-center gap-2 mt-0.5">
                        <span className="uppercase text-[10px] text-primary font-semibold">{v.category}</span>
                        <span>•</span>
                        <span>{v.views} views</span>
                        <span>•</span>
                        <span>{v.sourceType}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Link to={`/watch/${v.slug || v.id}`}>
                      <Button variant="ghost" size="sm" className="h-8 px-2 text-xs text-muted-foreground hover:text-white">
                        <Eye className="h-3.5 w-3.5" />
                      </Button>
                    </Link>
                    <Button variant="ghost" size="sm" onClick={() => handleOpenEditVideo(v)} className="h-8 px-2 text-xs text-muted-foreground hover:text-white">
                      <Edit className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        {/* Videos Management Tab */}
        <TabsContent value="videos" className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl border border-white/10 bg-white/[0.03]">
            <div className="flex items-center gap-2 flex-1 max-w-sm">
              <Search className="h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search videos by title or TeraBox ID..."
                value={videoSearch}
                onChange={(e) => setVideoSearch(e.target.value)}
                className="h-9 bg-background/50 text-xs border-border"
              />
            </div>
            <div className="flex items-center gap-2">
              <Select value={videoCategoryFilter} onValueChange={setVideoCategoryFilter}>
                <SelectTrigger className="w-[140px] h-9 text-xs bg-background border-border">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  <SelectItem value="all" className="text-xs">All Genres</SelectItem>
                  {categories.map((c) => (
                    <SelectItem key={c.id} value={c.slug} className="text-xs">{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button onClick={handleOpenAddVideo} size="sm" className="bg-primary hover:bg-primary/90 text-white text-xs h-9">
                <Plus className="h-3.5 w-3.5 mr-1" /> Add Video
              </Button>
            </div>
          </div>

          {/* Videos Table */}
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] overflow-hidden">
            <div className="w-full overflow-x-auto">
              <table className="w-full text-left text-xs text-foreground">
                <thead className="bg-white/5 border-b border-white/10 text-muted-foreground uppercase font-semibold text-[11px]">
                  <tr>
                    <th className="p-3.5">Video Details</th>
                    <th className="p-3.5">Category</th>
                    <th className="p-3.5">Source Type</th>
                    <th className="p-3.5">Views</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredVideos.map((v) => (
                    <tr key={v.id} className="hover:bg-white/[0.02]">
                      <td className="p-3.5 min-w-[280px]">
                        <div className="flex items-center gap-3">
                          <img src={v.thumbnail} alt={v.title} className="h-12 w-20 object-cover rounded-lg shrink-0" />
                          <div className="min-w-0">
                            <div className="font-bold text-white line-clamp-1">{v.title}</div>
                            <div className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">{v.description}</div>
                            {v.teraboxShareId && (
                              <span className="font-mono text-[10px] text-primary">ID: {v.teraboxShareId}</span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="p-3.5 whitespace-nowrap capitalize">{v.category}</td>
                      <td className="p-3.5 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-white/5 border border-white/10 uppercase">
                          {v.sourceType}
                        </span>
                      </td>
                      <td className="p-3.5 whitespace-nowrap">{v.views.toLocaleString()}</td>
                      <td className="p-3.5 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-400">
                          {v.status}
                        </span>
                      </td>
                      <td className="p-3.5 whitespace-nowrap text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Link to={`/watch/${v.slug || v.id}`}>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-white" title="Preview video page">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </Link>
                          <Button variant="ghost" size="icon" onClick={() => handleOpenEditVideo(v)} className="h-8 w-8 text-muted-foreground hover:text-white" title="Edit">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDeleteVideo(v.id)} className="h-8 w-8 text-muted-foreground hover:text-destructive" title="Delete">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>

        {/* Ndus Tokens Pool & Auto-Failover Tab */}
        <TabsContent value="tokens" className="space-y-6">
          <NdusTokenManager />
          <StreamDiagnose />
        </TabsContent>

        {/* Bulk Import Tab */}
        <TabsContent value="bulk" className="space-y-4">
          <div className="p-6 rounded-3xl border border-white/10 bg-white/[0.03] backdrop-blur-md">
            <h3 className="text-base font-bold text-white mb-2 flex items-center gap-2">
              <Upload className="h-5 w-5 text-primary" />
              Multi-Link TeraBox Bulk Importer
            </h3>
            <p className="text-xs text-muted-foreground mb-4">
              Paste multiple TeraBox links or embed codes (one per line). The parser will automatically generate catalog records and stream embed mappings.
            </p>

            <div className="space-y-4 max-w-2xl">
              <div>
                <label className="text-xs font-semibold text-foreground/80 mb-1.5 block">
                  Assign Category
                </label>
                <Select value={bulkCategory} onValueChange={setBulkCategory}>
                  <SelectTrigger className="w-full h-10 text-xs bg-background border-border">
                    <SelectValue placeholder="Select Category" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    {categories.map((c) => (
                      <SelectItem key={c.id} value={c.slug} className="text-xs">{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs font-semibold text-foreground/80 mb-1.5 block">
                  Paste TeraBox URLs / Embed Codes (One per line)
                </label>
                <Textarea
                  rows={5}
                  placeholder={`https://1024terabox.com/s/1DR0LCZe0GRoy6RkIL-3mmA
https://teraboxapp.com/s/1AbcDeFghIjkLmnOpQrStUv
https://nephobox.com/s/1ZyXwVuTsRqPoNmLkJiHgFe`}
                  value={bulkInput}
                  onChange={(e) => setBulkInput(e.target.value)}
                  className="bg-background font-mono text-xs border-border"
                />
              </div>

              <div>
                <ThumbnailUploader
                  value={bulkThumbnail}
                  onChange={setBulkThumbnail}
                />
              </div>

              {bulkStatus && (
                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 shrink-0" />
                  {bulkStatus}
                </div>
              )}

              <Button onClick={handleBulkImport} className="bg-primary hover:bg-primary/90 text-white font-bold text-xs h-10 px-6">
                Batch Import Videos Now
              </Button>
            </div>
          </div>
        </TabsContent>

        {/* Categories Tab */}
        <TabsContent value="categories" className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-2xl border border-white/10 bg-white/[0.03]">
            <div>
              <h3 className="text-sm font-bold text-white">Video Categories & Genres</h3>
              <p className="text-xs text-muted-foreground">Manage organization taxonomy for user filtering.</p>
            </div>
            <Button
              onClick={() => {
                setCategoryForm({ id: '', name: '', slug: '', description: '' });
                setCategoryModalOpen(true);
              }}
              size="sm"
              className="bg-primary hover:bg-primary/90 text-white text-xs h-9"
            >
              <Plus className="h-3.5 w-3.5 mr-1" /> Add Category
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map((cat) => {
              const count = videos.filter((v) => v.category === cat.slug).length;
              return (
                <div key={cat.id} className="p-4 rounded-2xl border border-white/10 bg-white/[0.02] flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-white">{cat.name}</h4>
                    <p className="text-xs text-muted-foreground line-clamp-1">{cat.description || `Slug: ${cat.slug}`}</p>
                    <span className="text-[11px] text-primary font-medium mt-1 inline-block">{count} videos</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        setCategoryForm({
                          id: cat.id,
                          name: cat.name,
                          slug: cat.slug,
                          description: cat.description || '',
                        });
                        setCategoryModalOpen(true);
                      }}
                      className="h-8 w-8 text-muted-foreground hover:text-white"
                    >
                      <Edit className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDeleteCategory(cat.id)}
                      className="h-8 w-8 text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </TabsContent>

        {/* Ads & Monetization Tab */}
        <TabsContent value="ads" className="space-y-4">
          <div className="p-5 rounded-3xl border border-white/10 bg-white/[0.03] backdrop-blur-md">
            <h3 className="text-base font-bold text-white mb-1 flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-emerald-400" />
              Adsterra & Monetization Placements
            </h3>
            <p className="text-xs text-muted-foreground mb-6">
              Har slot mein Adsterra ka code paste karein aur Enabled on karein. Ads async + alag iframe mein load hote hain, isliye site slow nahi hoti. Save karte hi server par jata hai aur sab devices par live ho jata hai.
            </p>

            <div className="mb-6 grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-3">
                <div className="text-lg font-black text-emerald-300">{ads.filter((a) => a.enabled && (hasRunnableCode(a.code) || hasRunnableCode(a.mobileCode))).length}</div>
                <div className="text-[11px] text-muted-foreground">Live slots</div>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-3">
                <div className="text-lg font-black text-amber-300">{ads.filter((a) => !hasRunnableCode(a.code) && !hasRunnableCode(a.mobileCode)).length}</div>
                <div className="text-[11px] text-muted-foreground">Code paste hona baaki</div>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-3 text-[11px] leading-relaxed text-muted-foreground">
                Tip: pehle <b className="text-white/80">Popunder</b>, <b className="text-white/80">Social Bar</b> aur 1-2 banner slots shuru karein. Har slot mein sahi format ka code hi paste karein - dialog mein code check aur preview milega.
              </div>
            </div>

            <div className="space-y-4">
              {ads.map((ad) => {
                const ready = hasRunnableCode(ad.code) || hasRunnableCode(ad.mobileCode);
                return (
                  <div key={ad.id} className="p-4 rounded-2xl border border-white/10 bg-white/[0.02] flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="text-sm font-bold text-white">{ad.name}</h4>
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-primary/20 text-primary">{ad.dimensions}</span>
                        {!ready ? (
                          <span className="cm-chip cm-chip-warn">Code paste karein</span>
                        ) : ad.enabled ? (
                          <span className="cm-chip cm-chip-on">LIVE</span>
                        ) : (
                          <span className="cm-chip cm-chip-off">Off</span>
                        )}
                        {ad.deviceTarget !== 'all' && <span className="cm-chip cm-chip-off">{ad.deviceTarget} only</span>}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">{ad.notes}</p>
                      {ready && (() => {
                        const r = analyzeAdCode(hasRunnableCode(ad.code) ? ad.code : ad.mobileCode, SLOT_BY_POSITION[ad.position]?.mode ?? 'banner');
                        return r.ok ? null : <p className="mt-1 text-[11px] text-amber-300">⚠ {r.notes[0]}</p>;
                      })()}
                    </div>

                    <div className="flex items-center gap-4 shrink-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">Enabled:</span>
                        <Switch checked={ad.enabled} onCheckedChange={() => handleToggleAd(ad)} />
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setEditingAd(ad);
                          setAdPreview(null);
                          setAdModalOpen(true);
                        }}
                        className="h-8 text-xs border border-white/10 hover:bg-white/10"
                      >
                        Edit Code
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-4">
          <div className="p-6 rounded-3xl border border-white/10 bg-white/[0.03] backdrop-blur-md max-w-3xl">
            <h3 className="text-base font-bold text-white mb-1 flex items-center gap-2">
              <Settings className="h-5 w-5 text-primary" />
              Website Branding & Configuration
            </h3>
            <p className="text-xs text-muted-foreground mb-6">
              Customize website name, header announcement, SEO meta tags, and adblocker notices.
            </p>

            <form onSubmit={handleSaveSettings} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-foreground/80 mb-1.5 block">
                    Website Name
                  </label>
                  <Input
                    value={settings.siteName}
                    onChange={(e) => setSettings({ ...settings, siteName: e.target.value })}
                    className="h-10 bg-background/50 border-border text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-foreground/80 mb-1.5 block">
                    Logo Text (Navbar)
                  </label>
                  <Input
                    value={settings.logoText}
                    onChange={(e) => setSettings({ ...settings, logoText: e.target.value })}
                    className="h-10 bg-background/50 border-border text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-foreground/80 mb-1.5 block">Logo Image URL</label>
                <Input value={settings.logoUrl || ''} onChange={(e) => setSettings({ ...settings, logoUrl: e.target.value })} placeholder="https://.../logo.png" className="h-10 bg-background/50 border-border text-xs" />
              </div>
              <div>
                <label className="text-xs font-semibold text-foreground/80 mb-1.5 block">
                  Tagline / Description
                </label>
                <Input
                  value={settings.tagline}
                  onChange={(e) => setSettings({ ...settings, tagline: e.target.value })}
                  className="h-10 bg-background/50 border-border text-xs"
                />
              </div>

              {/* Announcement Banner */}
              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-white">Top Announcement Bar</label>
                  <Switch
                    checked={settings.showAnnouncement}
                    onCheckedChange={(checked) => setSettings({ ...settings, showAnnouncement: checked })}
                  />
                </div>
                <Input
                  placeholder="Announcement text to display at the very top"
                  value={settings.announcementText}
                  onChange={(e) => setSettings({ ...settings, announcementText: e.target.value })}
                  className="h-10 bg-background/50 border-border text-xs"
                />
              </div>

              <div className="flex items-center justify-between p-4 rounded-2xl bg-white/[0.02] border border-white/5">
                <div>
                  <div className="text-xs font-bold text-white">Intermediate page ("Please wait N seconds...")</div>
                  <div className="text-[11px] text-muted-foreground mt-0.5">Video kholne se pehle ek wait page dikhega jisme ads hote hain (har video par 30 min mein ek baar).</div>
                </div>
                <Switch checked={Boolean(settings.showIntermediatePage)} onCheckedChange={(checked) => setSettings({ ...settings, showIntermediatePage: checked })} />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><label className="text-xs font-semibold text-foreground/80 mb-1.5 block">Popunder frequency cap (hours)</label><Input type="number" min={1} value={settings.popunderFrequencyHours || 24} onChange={(e) => setSettings({ ...settings, popunderFrequencyHours: Number(e.target.value) || 24 })} className="h-10 bg-background/50 border-border text-xs" /></div>
                <div><label className="text-xs font-semibold text-foreground/80 mb-1.5 block">Intermediate wait (seconds)</label><Input type="number" min={0} value={settings.intermediateWaitSeconds || 5} onChange={(e) => setSettings({ ...settings, intermediateWaitSeconds: Number(e.target.value) || 5 })} className="h-10 bg-background/50 border-border text-xs" /></div>
              </div>
              {/* Adblock Notice */}
              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-white">Ad-Blocker Friendly Notice</label>
                  <Switch
                    checked={settings.showAdblockNotice}
                    onCheckedChange={(checked) => setSettings({ ...settings, showAdblockNotice: checked })}
                  />
                </div>
                <Input
                  placeholder="Notice Title"
                  value={settings.adblockNoticeTitle}
                  onChange={(e) => setSettings({ ...settings, adblockNoticeTitle: e.target.value })}
                  className="h-10 bg-background/50 border-border text-xs"
                />
                <Textarea
                  placeholder="Notice message politely asking viewers to whitelist"
                  value={settings.adblockNoticeMessage}
                  onChange={(e) => setSettings({ ...settings, adblockNoticeMessage: e.target.value })}
                  rows={2}
                  className="bg-background/50 border-border text-xs"
                />
              </div>

              {/* Social URLs */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-foreground/80 mb-1.5 block">
                    Telegram Channel URL
                  </label>
                  <Input
                    value={settings.telegramUrl || ''}
                    onChange={(e) => setSettings({ ...settings, telegramUrl: e.target.value })}
                    className="h-10 bg-background/50 border-border text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-foreground/80 mb-1.5 block">
                    WhatsApp Group / Channel URL
                  </label>
                  <Input
                    value={settings.whatsappUrl || ''}
                    onChange={(e) => setSettings({ ...settings, whatsappUrl: e.target.value })}
                    className="h-10 bg-background/50 border-border text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-foreground/80 mb-1.5 block">
                  Footer Copyright / Text
                </label>
                <Input
                  value={settings.footerText}
                  onChange={(e) => setSettings({ ...settings, footerText: e.target.value })}
                  className="h-10 bg-background/50 border-border text-xs"
                />
              </div>

              <Button type="submit" className="bg-primary hover:bg-primary/90 text-white font-bold text-xs h-10 px-6">
                Save Platform Settings
              </Button>
            </form>
          </div>
        </TabsContent>
      </Tabs>

      {/* Video Add / Edit Modal */}
      <Dialog open={videoModalOpen} onOpenChange={setVideoModalOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl bg-card border-border text-foreground max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-base font-bold flex items-center gap-2">
              <Film className="h-5 w-5 text-primary" />
              {editingVideo ? 'Edit Video Details' : 'Add New TeraBox Video / Embed Stream'}
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSaveVideo} className="space-y-4 py-2">
            <div>
              <label className="text-xs font-semibold text-foreground/80 mb-1 block">
                TeraBox URL / Embed Code / Direct Video URL *
              </label>
              <Input
                placeholder="e.g. https://1024terabox.com/s/1DR0LCZe0GRoy6RkIL-3mmA or <iframe src='...'></iframe>"
                value={formData.videoUrl}
                onChange={(e) => handleUrlChange(e.target.value)}
                className="bg-background text-xs font-mono"
                required
              />
              <span className="text-[11px] text-muted-foreground mt-0.5 block">
                Supports TeraBox share links, official embed links, direct MP4 / HLS m3u8 streams, or iframe codes.
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-foreground/80 mb-1 block">
                  Video Title *
                </label>
                <Input
                  placeholder="Enter title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="bg-background text-xs"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-foreground/80 mb-1 block">
                  Category Genre
                </label>
                <Select
                  value={formData.category}
                  onValueChange={(val) => setFormData({ ...formData, category: val })}
                >
                  <SelectTrigger className="bg-background text-xs">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover">
                    {categories.map((c) => (
                      <SelectItem key={c.id} value={c.slug} className="text-xs">{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Direct Thumbnail Image Uploader (File dropzone, base64 local storage, instant preview) */}
            <ThumbnailUploader
              value={formData.thumbnail}
              onChange={(val) => setFormData({ ...formData, thumbnail: val })}
            />

            {/* Optional Direct Stream / Fallback Stream URL */}
            <div>
              <label className="text-xs font-semibold text-foreground/80 mb-1 block">
                Direct Stream Media URL (Optional MP4 / HLS .m3u8)
              </label>
              <Input
                placeholder="https://.../stream.mp4 or .m3u8 (Enables high-performance HD Player)"
                value={formData.directStreamUrl}
                onChange={(e) => setFormData({ ...formData, directStreamUrl: e.target.value })}
                className="bg-background text-xs font-mono"
              />
              <span className="text-[11px] text-muted-foreground mt-0.5 block">
                Leave empty to automatically stream using multi-mirror cloud embed and adaptive HD fallback.
              </span>
            </div>

            <div>
              <label className="text-xs font-semibold text-foreground/80 mb-1 block">
                Description
              </label>
              <Textarea
                rows={3}
                placeholder="Overview of the video..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bg-background text-xs"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs font-semibold text-foreground/80 mb-1 block">
                  Tags (comma separated)
                </label>
                <Input
                  placeholder="Action, 1080P, Anime"
                  value={formData.tags}
                  onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                  className="bg-background text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-foreground/80 mb-1 block">
                  Duration (seconds)
                </label>
                <Input
                  type="number"
                  value={formData.duration}
                  onChange={(e) => setFormData({ ...formData, duration: Number(e.target.value) })}
                  className="bg-background text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-foreground/80 mb-1 block">
                  Custom Slug (optional)
                </label>
                <Input
                  placeholder="custom-video-slug"
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  className="bg-background text-xs font-mono"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-6 pt-2">
              <label className="flex items-center gap-2 cursor-pointer text-xs">
                <Switch
                  checked={formData.featured}
                  onCheckedChange={(checked) => setFormData({ ...formData, featured: checked })}
                />
                <span className="font-semibold text-white">Featured on Homepage Hero</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer text-xs">
                <Switch
                  checked={formData.trending}
                  onCheckedChange={(checked) => setFormData({ ...formData, trending: checked })}
                />
                <span className="font-semibold text-white">Trending Showcase</span>
              </label>
            </div>

            <DialogFooter className="pt-4 border-t border-border">
              <Button type="button" variant="ghost" onClick={() => setVideoModalOpen(false)} className="text-xs">
                Cancel
              </Button>
              <Button type="submit" className="bg-primary hover:bg-primary/90 text-white font-bold text-xs">
                {editingVideo ? 'Update Video' : 'Save & Publish Video'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Category Modal */}
      <Dialog open={categoryModalOpen} onOpenChange={setCategoryModalOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md bg-card border-border text-foreground">
          <DialogHeader>
            <DialogTitle className="text-base font-bold flex items-center gap-2">
              <Layers className="h-5 w-5 text-primary" />
              {categoryForm.id ? 'Edit Category' : 'Add New Category'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSaveCategory} className="space-y-3 py-2">
            <div>
              <label className="text-xs font-semibold mb-1 block">Category Name *</label>
              <Input
                placeholder="e.g. Sci-Fi & Cyberpunk"
                value={categoryForm.name}
                onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })}
                className="bg-background text-xs"
                required
              />
            </div>
            <div>
              <label className="text-xs font-semibold mb-1 block">Slug (URL friendly)</label>
              <Input
                placeholder="sci-fi"
                value={categoryForm.slug}
                onChange={(e) => setCategoryForm({ ...categoryForm, slug: e.target.value })}
                className="bg-background text-xs font-mono"
              />
            </div>
            <div>
              <label className="text-xs font-semibold mb-1 block">Description</label>
              <Input
                placeholder="Short description"
                value={categoryForm.description}
                onChange={(e) => setCategoryForm({ ...categoryForm, description: e.target.value })}
                className="bg-background text-xs"
              />
            </div>
            <DialogFooter className="pt-2">
              <Button type="button" variant="ghost" onClick={() => setCategoryModalOpen(false)} className="text-xs">
                Cancel
              </Button>
              <Button type="submit" className="bg-primary hover:bg-primary/90 text-white text-xs">
                Save Category
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Ad Unit Edit Modal */}
      <Dialog open={adModalOpen} onOpenChange={(open) => { setAdModalOpen(open); if (!open) setAdPreview(null); }}>
        <DialogContent className="max-h-[92vh] overflow-y-auto max-w-[calc(100%-2rem)] md:max-w-2xl bg-card border-border text-foreground">
          <DialogHeader>
            <DialogTitle className="text-base font-bold flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-emerald-400" />
              {editingAd ? editingAd.name : 'Ad slot'}
            </DialogTitle>
          </DialogHeader>
          {editingAd && (() => {
            const slot = SLOT_BY_POSITION[editingAd.position];
            const mode = slot?.mode ?? 'banner';
            const report = analyzeAdCode(editingAd.code, mode);
            const canPreview = (mode === 'banner' || mode === 'native') && hasRunnableCode(editingAd.code);
            const previewCode = (adPreview?.code ?? '').trim();
            return (
              <form onSubmit={handleSaveAd} className="space-y-4 py-2">
                <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3 text-[11px] leading-relaxed text-muted-foreground">
                  <div><b className="text-white/80">Kahan dikhega:</b> {slot?.where}</div>
                  <div className="mt-1"><b className="text-white/80">Kaunsa code:</b> {slot?.how}</div>
                </div>

                <div>
                  <label className="text-xs font-semibold mb-1 block">Ad code (Adsterra se jaisa mila waisa paste karein)</label>
                  <Textarea
                    rows={6}
                    spellCheck={false}
                    placeholder={mode === 'popunder' ? '<script src="https://.../xxxx.js"></script>   ya   https://...direct-link...' : mode === 'global' ? '<script src="https://.../xxxx.js"></script>' : mode === 'native' ? '<script async src="https://.../invoke.js"></script>\n<div id="container-xxxx"></div>' : "<script>atOptions = { 'key': '...', 'format': 'iframe', 'height': 90, 'width': 728, 'params': {} };</script>\n<script src=\"//www.highperformanceformat.com/.../invoke.js\"></script>"}
                    value={editingAd.code}
                    onChange={(e) => {
                      const code = e.target.value;
                      // first time code is pasted: switch the slot on automatically (the most common thing people forget)
                      const firstPaste = !hasRunnableCode(editingAd.code) && hasRunnableCode(code) && !editingAd.enabled;
                      setEditingAd({ ...editingAd, code, enabled: firstPaste ? true : editingAd.enabled });
                    }}
                    className="bg-background font-mono text-xs"
                  />
                  <div className={`mt-1.5 space-y-0.5 text-[11px] ${report.kind === 'empty' ? 'text-muted-foreground' : report.ok ? 'text-emerald-300' : 'text-amber-300'}`}>
                    {report.notes.map((n, i) => <div key={i}>{report.ok ? '✓' : '⚠'} {n}</div>)}
                  </div>
                </div>

                {mode === 'banner' && (
                  <div>
                    <label className="text-xs font-semibold mb-1 block">Mobile code (optional, jaise 320x50 banner)</label>
                    <Textarea
                      rows={4}
                      spellCheck={false}
                      value={editingAd.mobileCode || ''}
                      onChange={(e) => setEditingAd({ ...editingAd, mobileCode: e.target.value })}
                      className="bg-background font-mono text-xs"
                    />
                    <span className="text-[11px] text-muted-foreground mt-0.5 block">
                      Phone (768px se chhoti screen) par yahi code chalega. Khali chhodein to upar wala code chhota karke dikhaya jayega.
                    </span>
                  </div>
                )}

                {canPreview && (
                  <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                    <div className="mb-2 flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold">Preview</span>
                      <Button type="button" variant="ghost" size="sm" className="h-7 border border-white/10 text-[11px]" onClick={() => setAdPreview({ code: editingAd.code, n: (adPreview?.n ?? 0) + 1 })}>
                        {adPreview ? 'Reload preview' : 'Ad preview dekhein'}
                      </Button>
                    </div>
                    {adPreview ? (
                      <div className="overflow-hidden rounded-lg bg-black/30 p-2">
                        <AdFrame key={adPreview.n} code={previewCode} fixed={mode === 'banner' ? parseAdSize(previewCode, editingAd.dimensions) : null} eager />
                        <p className="mt-2 text-[11px] text-muted-foreground">Khali dikhe to: AdBlock band karein, ya Adsterra mein site approve / ad unit active hai ye check karein (naye unit ko 10-30 min lag sakte hain).</p>
                      </div>
                    ) : (
                      <p className="text-[11px] text-muted-foreground">Save karne se pehle yahin dekh lein ki ad load ho raha hai ya nahi.</p>
                    )}
                  </div>
                )}

                <div>
                  <label className="text-xs font-semibold mb-1 block">Kaun si device par dikhana hai</label>
                  <select
                    className="cm-select"
                    value={editingAd.deviceTarget || 'all'}
                    onChange={(e) => setEditingAd({ ...editingAd, deviceTarget: e.target.value as AdUnit['deviceTarget'] })}
                  >
                    <option value="all">Sab devices</option>
                    <option value="mobile">Sirf mobile</option>
                    <option value="desktop">Sirf desktop</option>
                  </select>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02] border border-white/5">
                  <span className="text-xs font-semibold">Enabled (visitors ko dikhana hai)</span>
                  <Switch
                    checked={editingAd.enabled}
                    onCheckedChange={(checked) => setEditingAd({ ...editingAd, enabled: checked })}
                  />
                </div>

                <DialogFooter className="pt-2 gap-2">
                  {hasRunnableCode(editingAd.code) && (
                    <Button type="button" variant="ghost" onClick={() => setEditingAd({ ...editingAd, code: '', mobileCode: '', enabled: false })} className="text-xs text-red-300 sm:mr-auto">
                      Code hata dein
                    </Button>
                  )}
                  <Button type="button" variant="ghost" onClick={() => setAdModalOpen(false)} className="text-xs">
                    Cancel
                  </Button>
                  <Button type="submit" className="bg-primary hover:bg-primary/90 text-white text-xs">
                    Save
                  </Button>
                </DialogFooter>
              </form>
            );
          })()}
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};
