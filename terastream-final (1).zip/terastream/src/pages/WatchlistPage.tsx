import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { VideoCard } from '@/components/video/VideoCard';
import { storageService } from '@/services/storageService';
import { VideoItem } from '@/types/video';
import { Button } from '@/components/ui/button';
import { Bookmark, Trash2, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

export const WatchlistPage: React.FC = () => {
  const [watchlistVideos, setWatchlistVideos] = useState<VideoItem[]>([]);

  const loadWatchlist = () => {
    const allVideos = storageService.getVideos();
    const interactions = storageService.getUserInteractions();
    const saved = allVideos.filter((v) => interactions.watchlist.includes(v.id));
    setWatchlistVideos(saved);
  };

  useEffect(() => {
    loadWatchlist();
  }, []);

  const handleClearAll = () => {
    if (confirm('Are you sure you want to clear your saved Watchlist?')) {
      const interactions = storageService.getUserInteractions();
      interactions.watchlist = [];
      storageService.saveUserInteractions(interactions);
      setWatchlistVideos([]);
      toast.success('Watchlist cleared');
    }
  };

  return (
    <MainLayout>
      <div className="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.22em] text-violet-300/80">
            <Bookmark className="h-3.5 w-3.5" /> Saved for later
          </p>
          <h1 className="mt-2 font-display text-3xl md:text-4xl font-black tracking-tight text-white flex flex-wrap items-center gap-3">
            My Watchlist
            {watchlistVideos.length > 0 && (
              <span className="inline-flex items-center justify-center h-7 min-w-7 px-2 rounded-full bg-violet-500/15 border border-violet-400/25 text-sm font-bold text-violet-300">
                {watchlistVideos.length}
              </span>
            )}
          </h1>
          <p className="text-xs text-muted-foreground mt-1.5">
            Your personal collection of saved videos, stored on this device.
          </p>
        </div>

        {watchlistVideos.length > 0 && (
          <Button
            variant="outline"
            size="sm"
            onClick={handleClearAll}
            className="border-rose-500/30 text-rose-400 hover:bg-rose-500/10 hover:text-rose-300 hover:border-rose-500/50 text-xs h-9 gap-1.5 rounded-full"
          >
            <Trash2 className="h-3.5 w-3.5" /> Clear Watchlist
          </Button>
        )}
      </div>

      {watchlistVideos.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {watchlistVideos.map((video) => (
            <VideoCard
              key={video.id}
              video={video}
              onWatchlistChange={loadWatchlist}
            />
          ))}
        </div>
      ) : (
        <div className="relative overflow-hidden flex flex-col items-center justify-center py-16 my-8 rounded-3xl border border-dashed border-white/[0.1] bg-white/[0.015] text-center">
          <div className="absolute -top-16 left-1/2 -translate-x-1/2 h-40 w-72 rounded-full bg-violet-600/10 blur-[70px] pointer-events-none" />
          <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500/15 to-fuchsia-500/10 ring-1 ring-violet-400/20 text-violet-300 mb-5">
            <Bookmark className="h-7 w-7" />
          </div>
          <h3 className="relative font-display text-lg font-bold text-white mb-1.5">
            Your Watchlist is empty
          </h3>
          <p className="relative text-xs text-muted-foreground max-w-sm mb-6 leading-relaxed">
            Bookmark videos you like by tapping the bookmark icon on any video card, and they'll
            show up here.
          </p>
          <Link to="/browse">
            <Button className="relative bg-gradient-to-r from-violet-600 to-fuchsia-500 hover:brightness-110 text-white text-xs h-10 px-6 font-semibold rounded-full gap-1.5 shadow-md shadow-violet-500/25">
              Explore Videos <ArrowRight className="h-3.5 w-3.5" />
            </Button>
          </Link>
        </div>
      )}
    </MainLayout>
  );
};
