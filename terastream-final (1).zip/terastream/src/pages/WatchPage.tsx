import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { TeraboxPlayer } from '@/components/player/TeraboxPlayer';
import { ShareModal } from '@/components/common/ShareModal';
import { VideoCard } from '@/components/video/VideoCard';
import { AdSlot } from '@/components/ads/AdSlot';
import { hasPassedWait } from '@/pages/WaitPage';
import { storageService } from '@/services/storageService';
import { VideoItem, VideoComment } from '@/types/video';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import {
  ThumbsUp,
  ThumbsDown,
  Share2,
  Bookmark,
  Eye,
  Calendar,
  MessageSquare,
  Sparkles,
  ChevronRight,
  Send,
  Clock,
} from 'lucide-react';
import { toast } from 'sonner';

const AVATAR_GRADIENTS = [
  'from-violet-500 to-fuchsia-500',
  'from-cyan-500 to-blue-500',
  'from-amber-500 to-orange-500',
  'from-emerald-500 to-teal-500',
  'from-rose-500 to-pink-500',
];

export const WatchPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [video, setVideo] = useState<VideoItem | null>(null);
  const [relatedVideos, setRelatedVideos] = useState<VideoItem[]>([]);
  const [isTheaterMode, setIsTheaterMode] = useState<boolean>(false);
  const [shareModalOpen, setShareModalOpen] = useState<boolean>(false);

  // Interaction states
  const [isLiked, setIsLiked] = useState<boolean>(false);
  const [isDisliked, setIsDisliked] = useState<boolean>(false);
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [selectedEmoji, setSelectedEmoji] = useState<string | null>(null);

  // Comments
  const [comments, setComments] = useState<VideoComment[]>([]);
  const [commentName, setCommentName] = useState<string>('');
  const [commentText, setCommentText] = useState<string>('');

  // Expand description
  const [showFullDesc, setShowFullDesc] = useState<boolean>(false);

  useEffect(() => {
    if (!id) return;

    const found = storageService.getVideoById(id);
    if (!found) {
      toast.error('Video not found');
      navigate('/');
      return;
    }

    // optional intermediate "Please wait N seconds" page (admin setting)
    if (storageService.getSettings().showIntermediatePage && !hasPassedWait(found.id)) {
      navigate(`/wait/${id}`, { replace: true });
      return;
    }

    setVideo(found);
    storageService.incrementViews(found.id);

    // Load related videos
    const all = storageService.getVideos();
    const related = all
      .filter((v) => v.id !== found.id && (v.category === found.category || v.trending))
      .slice(0, 8);
    setRelatedVideos(related);

    // Load user interactions
    const interactions = storageService.getUserInteractions();
    setIsSaved(interactions.watchlist.includes(found.id));
    setIsLiked(interactions.likedVideos.includes(found.id));
    setIsDisliked(interactions.dislikedVideos.includes(found.id));
    setSelectedEmoji(interactions.emojiReactions[found.id] || null);

    // Load comments
    setComments(storageService.getComments(found.id));

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [id, navigate]);

  if (!video) {
    return (
      <MainLayout>
        <div className="flex h-96 items-center justify-center text-muted-foreground text-sm">
          Loading video stream...
        </div>
      </MainLayout>
    );
  }

  const handleLike = () => {
    if (isLiked) return;
    const res = storageService.toggleLike(video.id, true);
    setIsLiked(true);
    setIsDisliked(false);
    setVideo((prev) => (prev ? { ...prev, likes: res.likes } : null));

    const interactions = storageService.getUserInteractions();
    if (!interactions.likedVideos.includes(video.id)) {
      interactions.likedVideos.push(video.id);
    }
    interactions.dislikedVideos = interactions.dislikedVideos.filter((i) => i !== video.id);
    storageService.saveUserInteractions(interactions);
    toast.success('Liked video!');
  };

  const handleDislike = () => {
    if (isDisliked) return;
    const res = storageService.toggleLike(video.id, false);
    setIsDisliked(true);
    setIsLiked(false);
    setVideo((prev) => (prev ? { ...prev, dislikes: res.dislikes } : null));

    const interactions = storageService.getUserInteractions();
    if (!interactions.dislikedVideos.includes(video.id)) {
      interactions.dislikedVideos.push(video.id);
    }
    interactions.likedVideos = interactions.likedVideos.filter((i) => i !== video.id);
    storageService.saveUserInteractions(interactions);
  };

  const handleToggleWatchlist = () => {
    const saved = storageService.toggleWatchlist(video.id);
    setIsSaved(saved);
    toast.success(saved ? 'Added to Watchlist!' : 'Removed from Watchlist');
  };

  const handleEmojiReaction = (emoji: string) => {
    setSelectedEmoji(emoji);
    storageService.recordReaction(video.id, emoji);
    toast.success(`Reacted with ${emoji}`);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    const newComment = storageService.addComment(video.id, commentName, commentText);
    setComments((prev) => [newComment, ...prev]);
    setCommentText('');
    toast.success('Comment posted!');
  };

  const emojis = ['🔥', '💖', '🍿', '😮', '👏', '🚀'];

  return (
    <MainLayout>
      {/* Breadcrumb Navigation */}
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground mb-4 overflow-x-auto whitespace-nowrap scrollbar-none">
        <Link to="/" className="hover:text-violet-300 transition-colors">Home</Link>
        <ChevronRight className="h-3 w-3 text-white/25 shrink-0" />
        <Link to={`/browse?category=${video.category}`} className="capitalize hover:text-violet-300 transition-colors">
          {video.category}
        </Link>
        <ChevronRight className="h-3 w-3 text-white/25 shrink-0" />
        <span className="text-white/80 truncate max-w-xs">{video.title}</span>
      </nav>

      {/* Theater Mode: Full Width Video Player Container */}
      {isTheaterMode && (
        <div className="w-full mb-6 animate-in fade-in duration-300">
          <div className="rounded-3xl shadow-2xl shadow-violet-950/50">
            <TeraboxPlayer
              video={video}
              isTheaterMode={isTheaterMode}
              onToggleTheater={() => setIsTheaterMode(!isTheaterMode)}
              onShareClick={() => setShareModalOpen(true)}
            />
          </div>
        </div>
      )}

      {/* Main Grid: Left Stream + Details | Right Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
        {/* Left Column */}
        <div className={`${isTheaterMode ? 'lg:col-span-3' : 'lg:col-span-2'} flex flex-col space-y-6`}>
          <AdSlot position="above_player" />

          {/* Normal Mode Video Player */}
          {!isTheaterMode && (
            <div className="rounded-2xl md:rounded-3xl shadow-2xl shadow-violet-950/50">
              <TeraboxPlayer
                video={video}
                isTheaterMode={isTheaterMode}
                onToggleTheater={() => setIsTheaterMode(!isTheaterMode)}
                onShareClick={() => setShareModalOpen(true)}
              />
            </div>
          )}

          {/* Ad Slot Under Video Player (Adsterra) */}
          <AdSlot position="below_player" />

          {/* Video Metadata Header */}
          <div className="p-5 md:p-6 rounded-3xl border border-white/[0.07] bg-card/60 backdrop-blur-md">
            {/* Title & Chips */}
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-[0.14em] bg-gradient-to-r from-violet-600 to-fuchsia-500 text-white shadow-md shadow-violet-500/25">
                {video.category}
              </span>
              {video.sourceType === 'terabox' && (
                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-cyan-500/15 text-cyan-300 border border-cyan-400/25">
                  HD Stream
                </span>
              )}
              {video.durationFormatted && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-white/[0.05] text-white/60 border border-white/[0.08]">
                  <Clock className="h-3 w-3" /> {video.durationFormatted}
                </span>
              )}
            </div>

            <h1 className="font-display text-xl md:text-2xl font-extrabold text-white leading-snug tracking-tight mb-4 break-words">
              {video.title}
            </h1>

            {/* Metrics & Action Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-4 border-t border-white/[0.07]">
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5 font-medium">
                  <Eye className="h-4 w-4 text-violet-300" />
                  {video.views.toLocaleString()} views
                </span>
                <span className="flex items-center gap-1.5 font-medium">
                  <Calendar className="h-4 w-4 text-muted-foreground/70" />
                  {new Date(video.createdAt).toLocaleDateString()}
                </span>
              </div>

              {/* Action Buttons: one tight row - like group + Share + Save (Source link removed) */}
              <div className="flex items-center gap-2">
                <div className="flex items-center rounded-full border border-white/[0.08] bg-white/[0.04] p-1">
                  <button
                    onClick={handleLike}
                    className={`inline-flex items-center gap-1.5 h-8 px-2.5 sm:px-3.5 rounded-full text-xs font-bold transition-all ${
                      isLiked
                        ? 'bg-gradient-to-r from-violet-600 to-fuchsia-500 text-white shadow-md shadow-violet-500/30'
                        : 'text-muted-foreground hover:text-white'
                    }`}
                  >
                    <ThumbsUp className={`h-3.5 w-3.5 shrink-0 ${isLiked ? 'fill-current' : ''}`} />
                    {video.likes.toLocaleString()}
                  </button>
                  <span className="h-4 w-px bg-white/10" />
                  <button
                    onClick={handleDislike}
                    className={`inline-flex items-center justify-center h-8 w-9 rounded-full text-xs font-bold transition-all ${
                      isDisliked ? 'bg-rose-500/20 text-rose-300' : 'text-muted-foreground hover:text-white'
                    }`}
                    title="Dislike"
                  >
                    <ThumbsDown className={`h-3.5 w-3.5 ${isDisliked ? 'fill-current' : ''}`} />
                  </button>
                </div>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShareModalOpen(true)}
                  title="Share"
                  className="h-9 px-2.5 sm:px-4 rounded-full border border-violet-400/30 bg-violet-500/10 hover:bg-violet-500/20 hover:border-violet-400/50 text-violet-200 font-semibold text-xs gap-1.5"
                >
                  <Share2 className="h-3.5 w-3.5 shrink-0" />
                  <span className="hidden sm:inline">Share</span>
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleToggleWatchlist}
                  title={isSaved ? 'Remove from Watchlist' : 'Save to Watchlist'}
                  className={`h-9 px-2.5 sm:px-4 rounded-full border text-xs font-semibold gap-1.5 ${
                    isSaved
                      ? 'bg-violet-500/20 text-violet-200 border-violet-400/40'
                      : 'border-white/[0.08] bg-white/[0.04] hover:bg-white/[0.08] hover:border-white/20'
                  }`}
                >
                  <Bookmark className={`h-3.5 w-3.5 shrink-0 ${isSaved ? 'fill-current' : ''}`} />
                  <span className="hidden sm:inline">{isSaved ? 'Saved' : 'Save'}</span>
                </Button>
              </div>
            </div>

            {/* Emoji Reactions Bar (wraps gracefully on small screens) */}
            <div className="mt-4 pt-4 border-t border-white/[0.05] flex flex-wrap items-center justify-between gap-x-3 gap-y-2">
              <span className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5">
                <Sparkles className="h-3.5 w-3.5 text-violet-300" /> React to this video
              </span>
              <div className="flex items-center gap-1.5">
                {emojis.map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => handleEmojiReaction(emoji)}
                    className={`h-8 w-8 rounded-full flex items-center justify-center text-sm transition-all hover:scale-125 active:scale-95 ${
                      selectedEmoji === emoji
                        ? 'bg-violet-500/25 border border-violet-400/50 scale-110'
                        : 'bg-white/[0.05] hover:bg-white/[0.12] border border-transparent'
                    }`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>

            {/* Expandable Description */}
            <div className="mt-4 pt-3 border-t border-white/[0.05] text-xs text-muted-foreground leading-relaxed break-words">
              <p className={showFullDesc ? '' : 'line-clamp-2'}>
                {video.description || 'No description provided for this video.'}
              </p>
              {video.description && video.description.length > 100 && (
                <button
                  onClick={() => setShowFullDesc(!showFullDesc)}
                  className="mt-1.5 text-violet-300 hover:text-violet-200 font-semibold transition-colors"
                >
                  {showFullDesc ? 'Show Less' : 'Read More'}
                </button>
              )}

              {/* Tags */}
              {video.tags && video.tags.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {video.tags.map((tag) => (
                    <Link
                      key={tag}
                      to={`/browse?search=${encodeURIComponent(tag)}`}
                      className="px-2.5 py-1 rounded-full bg-white/[0.04] hover:bg-violet-500/15 hover:text-violet-200 border border-white/[0.06] hover:border-violet-400/30 text-[11px] text-muted-foreground hover:text-white transition-all"
                    >
                      #{tag}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Comments Section */}
          <section className="p-5 md:p-6 rounded-3xl border border-white/[0.07] bg-card/60 backdrop-blur-md">
            <h3 className="font-display text-base font-bold text-white flex items-center gap-2 mb-5">
              <MessageSquare className="h-4 w-4 text-violet-300" />
              Viewer Comments
              <span className="inline-flex items-center justify-center h-5 min-w-5 px-1.5 rounded-full bg-white/[0.06] border border-white/[0.08] text-[10px] font-bold text-muted-foreground">
                {comments.length}
              </span>
            </h3>

            {/* Add Comment Form */}
            <form onSubmit={handleAddComment} className="space-y-3 mb-6 p-4 rounded-2xl bg-black/25 border border-white/[0.05]">
              <div className="flex flex-col sm:flex-row gap-3">
                <Input
                  type="text"
                  placeholder="Your name (optional)"
                  value={commentName}
                  onChange={(e) => setCommentName(e.target.value)}
                  className="h-9 sm:w-48 bg-white/[0.04] border-white/[0.08] text-xs rounded-xl focus-visible:border-violet-400/50"
                />
              </div>
              <Textarea
                placeholder="Share your thoughts about this video…"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                rows={2}
                className="bg-white/[0.04] border-white/[0.08] text-xs resize-none rounded-xl focus-visible:border-violet-400/50"
              />
              <div className="flex justify-end">
                <Button
                  type="submit"
                  disabled={!commentText.trim()}
                  className="bg-gradient-to-r from-violet-600 to-fuchsia-500 hover:brightness-110 text-white text-xs h-9 px-5 rounded-full font-semibold gap-1.5 shadow-md shadow-violet-500/25"
                >
                  <Send className="h-3 w-3" /> Post Comment
                </Button>
              </div>
            </form>

            {/* Comments List */}
            <div className="space-y-3">
              {comments.length === 0 && (
                <div className="rounded-2xl border border-dashed border-white/[0.08] py-5 text-center">
                  <p className="text-xs text-muted-foreground/70">
                    No comments yet — be the first to share your thoughts!
                  </p>
                </div>
              )}
              {comments.map((c, i) => (
                <div key={c.id} className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/[0.05] flex gap-3 hover:border-white/[0.09] transition-colors">
                  <div
                    className={`h-8 w-8 rounded-full bg-gradient-to-br ${
                      AVATAR_GRADIENTS[i % AVATAR_GRADIENTS.length]
                    } text-white flex items-center justify-center shrink-0 text-xs font-bold shadow-md`}
                  >
                    {c.userName.slice(0, 1).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-3 mb-1">
                      <span className="text-xs font-bold text-white truncate">{c.userName}</span>
                      <span className="text-[10px] text-muted-foreground/70 shrink-0">{c.createdAt}</span>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">{c.content}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Right Sidebar: Ad + Related Videos */}
        <div className="lg:col-span-1 space-y-6">
          <div className="lg:sticky lg:top-24 space-y-6">
            {/* Sidebar Banner Ad (Adsterra 300x250) */}
            <AdSlot position="watch_sidebar" />

            {/* Related Videos List */}
            <div className="p-4 rounded-3xl border border-white/[0.07] bg-card/60 backdrop-blur-md">
              <h3 className="font-display text-sm font-bold text-white flex items-center gap-2 mb-3 px-1">
                <Sparkles className="h-4 w-4 text-violet-300" />
                Related Videos
              </h3>

              <div className="space-y-2">
                {relatedVideos.map((item, i) => (
                  <React.Fragment key={item.id}>
                    <VideoCard video={item} variant="compact" />
                    {i === Math.min(2, relatedVideos.length - 1) && <AdSlot position="related_between" />}
                  </React.Fragment>
                ))}
                {relatedVideos.length === 0 && (
                  <p className="text-xs text-muted-foreground/70 text-center py-6">
                    No related videos yet.
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Advanced Share Modal */}
      <ShareModal
        video={video}
        isOpen={shareModalOpen}
        onOpenChange={setShareModalOpen}
      />
    </MainLayout>
  );
};
