import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { VideoCard } from '@/components/video/VideoCard';
import { AdSlot } from '@/components/ads/AdSlot';
import { storageService } from '@/services/storageService';
import { VideoItem, CategoryItem } from '@/types/video';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Compass, Search, SlidersHorizontal, Film, X } from 'lucide-react';

export const BrowsePage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [videos, setVideos] = useState<VideoItem[]>([]);
  const [categories, setCategories] = useState<CategoryItem[]>([]);

  const categoryParam = searchParams.get('category') || 'all';
  const sortParam = searchParams.get('sort') || 'newest';
  const searchParam = searchParams.get('search') || '';

  const [searchInput, setSearchInput] = useState(searchParam);

  useEffect(() => {
    setVideos(storageService.getVideos());
    setCategories(storageService.getCategories());
  }, []);

  useEffect(() => {
    setSearchInput(searchParam);
  }, [searchParam]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams(searchParams);
    if (searchInput.trim()) {
      params.set('search', searchInput.trim());
    } else {
      params.delete('search');
    }
    setSearchParams(params);
  };

  const handleCategorySelect = (slug: string) => {
    const params = new URLSearchParams(searchParams);
    if (slug === 'all') {
      params.delete('category');
    } else {
      params.set('category', slug);
    }
    setSearchParams(params);
  };

  const handleSortSelect = (sort: string) => {
    const params = new URLSearchParams(searchParams);
    params.set('sort', sort);
    setSearchParams(params);
  };

  const clearFilters = () => {
    setSearchInput('');
    setSearchParams({});
  };

  // Filter & Sort
  const filteredVideos = videos.filter((v) => {
    if (v.status !== 'published') return false;

    // Category filter
    if (categoryParam !== 'all' && v.category !== categoryParam) {
      return false;
    }

    // Search query filter
    if (searchParam.trim()) {
      const q = searchParam.toLowerCase();
      const matchTitle = v.title.toLowerCase().includes(q);
      const matchDesc = v.description.toLowerCase().includes(q);
      const matchTag = v.tags.some((t) => t.toLowerCase().includes(q));
      if (!matchTitle && !matchDesc && !matchTag) {
        return false;
      }
    }

    return true;
  });

  // Sorting
  filteredVideos.sort((a, b) => {
    if (sortParam === 'views') {
      return (b.views || 0) - (a.views || 0);
    }
    if (sortParam === 'likes') {
      return (b.likes || 0) - (a.likes || 0);
    }
    if (sortParam === 'trending') {
      return (b.trending ? 1 : 0) - (a.trending ? 1 : 0);
    }
    // Default newest
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  return (
    <MainLayout>
      {/* Page Header */}
      <div className="mb-6">
        <p className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.22em] text-violet-300/80">
          <Compass className="h-3.5 w-3.5" /> Explore the catalog
        </p>
        <div className="mt-2 flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl md:text-4xl font-black tracking-tight text-white">
              Browse Videos
            </h1>
            <p className="mt-1.5 text-xs md:text-sm text-muted-foreground">
              Movies, anime, series and trending drops — all in HD.
            </p>
          </div>

          {/* Search form */}
          <form onSubmit={handleSearchSubmit} className="flex items-center gap-2 md:max-w-sm w-full">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search title, genre, keyword…"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className="h-10 rounded-xl border-white/[0.08] bg-white/[0.04] pl-10 pr-3 text-xs text-foreground focus-visible:border-violet-400/50"
              />
            </div>
            <Button
              type="submit"
              size="sm"
              className="h-10 px-4 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-500 hover:brightness-110 text-white font-semibold text-xs shadow-md shadow-violet-500/25"
            >
              Search
            </Button>
          </form>
        </div>
      </div>

      {/* Sticky Filter Toolbar */}
      <div className="sticky top-[4.5rem] z-30 -mx-4 sm:-mx-6 lg:-mx-8 px-4 sm:px-6 lg:px-8 py-3 mb-6 bg-background/90 backdrop-blur-xl border-y border-white/[0.06]">
        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
          {/* Category Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none -mx-1 px-1 pb-0.5 sm:pb-0">
            <button
              onClick={() => handleCategorySelect('all')}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                categoryParam === 'all'
                  ? 'bg-gradient-to-r from-violet-600 to-fuchsia-500 text-white shadow-md shadow-violet-500/30'
                  : 'bg-white/[0.05] text-muted-foreground hover:text-white hover:bg-white/[0.09] border border-white/[0.06]'
              }`}
            >
              All
            </button>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => handleCategorySelect(cat.slug)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                  categoryParam === cat.slug
                    ? 'bg-gradient-to-r from-violet-600 to-fuchsia-500 text-white shadow-md shadow-violet-500/30'
                    : 'bg-white/[0.05] text-muted-foreground hover:text-white hover:bg-white/[0.09] border border-white/[0.06]'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>

          {/* Sort Dropdown + Reset */}
          <div className="flex items-center gap-2 sm:ml-auto shrink-0">
            <span className="hidden sm:flex items-center gap-1 text-xs text-muted-foreground font-medium">
              <SlidersHorizontal className="h-3.5 w-3.5" /> Sort
            </span>
            <Select value={sortParam} onValueChange={handleSortSelect}>
              <SelectTrigger className="w-[140px] h-9 text-xs bg-white/[0.04] border-white/[0.08] focus:ring-violet-400/30">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent className="bg-popover border-white/[0.08]">
                <SelectItem value="newest" className="text-xs">Latest Added</SelectItem>
                <SelectItem value="views" className="text-xs">Most Viewed</SelectItem>
                <SelectItem value="likes" className="text-xs">Most Liked</SelectItem>
                <SelectItem value="trending" className="text-xs">Trending</SelectItem>
              </SelectContent>
            </Select>

            {(categoryParam !== 'all' || searchParam || sortParam !== 'newest') && (
              <Button
                variant="ghost"
                size="sm"
                onClick={clearFilters}
                className="h-9 px-2.5 text-xs text-muted-foreground hover:text-white hover:bg-white/[0.06]"
                title="Reset filters"
              >
                <X className="h-3.5 w-3.5 mr-1" /> Reset
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between mb-4">
        <span className="text-xs text-muted-foreground">
          Showing{' '}
          <span className="font-bold text-white">{filteredVideos.length}</span>{' '}
          {filteredVideos.length === 1 ? 'video' : 'videos'}
          {categoryParam !== 'all' && (
            <span> in <span className="capitalize text-violet-300 font-semibold">{categoryParam}</span></span>
          )}
          {searchParam && <span> matching “{searchParam}”</span>}
        </span>
      </div>

      <AdSlot position="native_banner" />

      {/* Videos Grid */}
      {filteredVideos.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {filteredVideos.map((video, i) => (
            <React.Fragment key={video.id}>
              <VideoCard video={video} />
              {i === 7 && (
                <div style={{ gridColumn: '1 / -1' }}>
                  <AdSlot position="related_between" />
                </div>
              )}
            </React.Fragment>
          ))}
        </div>
      ) : (
        <div className="relative overflow-hidden flex flex-col items-center justify-center p-12 my-8 rounded-3xl border border-dashed border-white/[0.1] bg-white/[0.015] text-center">
          <div className="absolute -top-16 left-1/2 -translate-x-1/2 h-40 w-72 rounded-full bg-violet-600/10 blur-[70px] pointer-events-none" />
          <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500/15 to-fuchsia-500/10 ring-1 ring-violet-400/20 text-violet-300 mb-5">
            <Film className="h-7 w-7" />
          </div>
          <h3 className="relative font-display text-lg font-bold text-white mb-1.5">No videos found</h3>
          <p className="relative text-xs text-muted-foreground max-w-sm mb-6 leading-relaxed">
            We couldn't find any videos matching your search or filters. Try a different keyword or
            explore other categories.
          </p>
          <Button
            onClick={clearFilters}
            className="relative bg-gradient-to-r from-violet-600 to-fuchsia-500 hover:brightness-110 text-white text-xs h-10 px-5 font-semibold rounded-full shadow-md shadow-violet-500/25"
          >
            Clear All Filters
          </Button>
        </div>
      )}
    </MainLayout>
  );
};
