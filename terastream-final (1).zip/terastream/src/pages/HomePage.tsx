import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Clock,
  Eye,
  Flame,
  Film,
  LayoutGrid,
  Music,
  Play,
  Cpu,
  Sparkles,
  Star,
  Tv,
  Zap,
} from 'lucide-react';
import { MainLayout } from '@/components/layouts/MainLayout';
import { VideoCard } from '@/components/video/VideoCard';
import { AdSlot } from '@/components/ads/AdSlot';
import { Button } from '@/components/ui/button';
import { storageService } from '@/services/storageService';
import { VideoItem, CategoryItem } from '@/types/video';

const posterFallback = 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1280&auto=format&fit=crop&q=80';

const CATEGORY_ICONS: Record<string, React.ElementType> = {
  Film,
  Sparkles,
  Tv,
  Cpu,
  Music,
  Flame,
};

/** Icon component for a category (falls back to LayoutGrid). */
const CategoryIcon: React.FC<{ name?: string; className?: string }> = ({ name, className }) => {
  const Icon = (name && CATEGORY_ICONS[name]) || LayoutGrid;
  return <Icon className={className} />;
};

/** Horizontal snap-scroll rail with desktop arrows and edge fades. */
const Rail: React.FC<{
  title: string;
  kicker: string;
  icon: React.ReactNode;
  videos: VideoItem[];
}> = ({ title, kicker, icon, videos }) => {
  const scrollerRef = useRef<HTMLDivElement>(null);

  const scrollRail = (dir: 1 | -1) => {
    const el = scrollerRef.current;
    if (!el) return;
    el.scrollBy({ left: dir * Math.round(el.clientWidth * 0.85), behavior: 'smooth' });
  };

  if (!videos.length) return null;

  return (
    <section className="mb-12">
      <div className="mb-4 flex items-end justify-between gap-4">
        <div>
          <p className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.22em] text-violet-300/80">
            {icon}
            {kicker}
          </p>
          <h2 className="mt-1.5 font-display text-2xl font-extrabold tracking-tight text-white">
            {title}
          </h2>
        </div>
        <Link
          to="/browse"
          className="hidden sm:inline-flex items-center gap-1 h-8 px-3.5 rounded-full border border-white/[0.08] bg-white/[0.03] text-xs font-semibold text-muted-foreground hover:text-white hover:border-violet-400/40 hover:bg-violet-500/10 transition-all"
        >
          View all <ChevronRight className="h-3.5 w-3.5" />
        </Link>
      </div>

      <div className="group/rail relative">
        {/* Edge fades */}
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-8 bg-gradient-to-r from-background to-transparent opacity-0 group-hover/rail:opacity-100 transition-opacity hidden md:block" />

        {/* Left arrow */}
        <button
          type="button"
          onClick={() => scrollRail(-1)}
          className="hidden md:flex absolute -left-4 top-1/2 -translate-y-1/2 z-20 h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-background/90 text-white backdrop-blur-md shadow-xl opacity-0 group-hover/rail:opacity-100 hover:border-violet-400/50 hover:bg-violet-500/20 transition-all"
          title="Scroll left"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        {/* Right arrow */}
        <button
          type="button"
          onClick={() => scrollRail(1)}
          className="hidden md:flex absolute -right-4 top-1/2 -translate-y-1/2 z-20 h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-background/90 text-white backdrop-blur-md shadow-xl opacity-0 group-hover/rail:opacity-100 hover:border-violet-400/50 hover:bg-violet-500/20 transition-all"
          title="Scroll right"
        >
          <ChevronRight className="h-5 w-5" />
        </button>

        <div
          ref={scrollerRef}
          className="rail-scroll rail-mask -mx-1 flex gap-4 overflow-x-auto px-1 pb-3"
        >
          {videos.map((video) => (
            <div
              key={video.id}
              className="w-[58%] shrink-0 sm:w-[40%] md:w-[30.5%] lg:w-[23%] xl:w-[18.4%]"
            >
              <VideoCard video={video} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export const HomePage: React.FC = () => {
  const [videos, setVideos] = useState<VideoItem[]>([]);
  const [categories, setCategories] = useState<CategoryItem[]>([]);

  useEffect(() => {
    setVideos(storageService.getVideos().filter((v) => v.status !== 'draft'));
    setCategories(storageService.getCategories());
  }, []);

  const hero = videos.find((v) => v.featured) || videos[0];
  const trending = useMemo(() => [...videos].sort((a, b) => b.views - a.views).slice(0, 10), [videos]);
  const latest = useMemo(
    () => [...videos].sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)).slice(0, 10),
    [videos]
  );
  const anime = videos.filter((v) => v.category === 'anime').slice(0, 10);
  const movies = videos.filter((v) => v.category === 'movies').slice(0, 10);

  return (
    <MainLayout>
      {/* ===== Cinematic Hero (two-column with poster card) ===== */}
      <section className="relative -mx-4 sm:-mx-6 lg:-mx-8 -mt-6 lg:-mt-8 mb-14 overflow-hidden bg-[#07070d]">
        {hero && (
          <img
            src={hero.thumbnail || posterFallback}
            alt=""
            className="absolute inset-0 h-full w-full object-cover opacity-40 scale-105"
          />
        )}
        {/* Cinematic scrims */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#07070d] via-[#07070d]/80 to-[#07070d]/35" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#07070d] via-transparent to-[#07070d]/55" />
        {/* Ambient glows */}
        <div className="absolute -bottom-32 -left-32 h-96 w-96 rounded-full bg-violet-600/20 blur-[120px] pointer-events-none" />
        <div className="absolute -top-24 right-1/4 h-72 w-72 rounded-full bg-fuchsia-600/15 blur-[110px] pointer-events-none" />

        {/* px caps (not vh): mobile "desktop mode" renders a very tall virtual viewport, and a
            vh-based min-height used to blow the hero up into a huge box with big empty gaps */}
        <div className="relative mx-auto flex min-h-[560px] sm:min-h-[600px] lg:min-h-[620px] xl:min-h-[660px] max-w-7xl items-center px-4 sm:px-6 lg:px-8 py-12 sm:py-14 lg:py-16">
          <div className="grid w-full items-center gap-12 lg:grid-cols-[minmax(0,1fr)_340px] xl:grid-cols-[minmax(0,1fr)_380px]">
            {/* ---- Left: copy ---- */}
            <div className="max-w-2xl min-w-0 animate-fade-up">
              <div className="mb-5 flex flex-wrap items-center gap-2.5">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-violet-500/15 px-3.5 py-1.5 text-[11px] font-bold uppercase tracking-[0.18em] text-violet-200 ring-1 ring-violet-400/30 backdrop-blur-sm">
                  <Sparkles className="h-3 w-3" /> Featured tonight
                </span>
                {hero?.trending && (
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-500/15 px-3 py-1.5 text-[11px] font-bold text-amber-300 ring-1 ring-amber-400/30">
                    <Flame className="h-3 w-3" /> #Trending
                  </span>
                )}
                <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1.5 text-[11px] font-bold text-emerald-300 ring-1 ring-emerald-400/25">
                  <Zap className="h-3 w-3" /> Instant play
                </span>
              </div>

              <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-black leading-[1.02] tracking-[-0.03em] text-white break-words">
                {hero?.title || 'Your next obsession starts here.'}
              </h1>

              <p className="mt-5 max-w-xl text-sm sm:text-base leading-7 text-white/65 break-words">
                {hero?.description ||
                  'Discover movies, anime, series and viral drops in a fast, mobile-first streaming catalog.'}
              </p>

              {hero && (
                <div className="mt-5 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-white/55">
                  <span className="inline-flex items-center gap-1.5 capitalize">
                    <Film className="h-3.5 w-3.5 text-violet-300" /> {hero.category}
                  </span>
                  {hero.durationFormatted && (
                    <span className="inline-flex items-center gap-1.5">
                      <Clock className="h-3.5 w-3.5 text-violet-300" /> {hero.durationFormatted}
                    </span>
                  )}
                  <span className="inline-flex items-center gap-1.5">
                    <Eye className="h-3.5 w-3.5 text-violet-300" /> {hero.views.toLocaleString()} views
                  </span>
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-white/[0.06] px-2.5 py-1 font-bold text-white/80 ring-1 ring-white/10">
                    HD
                  </span>
                </div>
              )}

              <div className="mt-8 flex flex-wrap gap-3">
                <Link to={hero ? `/watch/${hero.slug || hero.id}` : '/browse'}>
                  <Button className="h-12 rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-500 px-7 text-sm font-bold text-white shadow-[0_8px_35px_rgba(168,85,247,0.4)] hover:shadow-[0_8px_45px_rgba(168,85,247,0.55)] hover:brightness-110 transition-all">
                    <Play className="mr-1 h-4 w-4 fill-current" /> Watch now
                  </Button>
                </Link>
                <Link to="/browse">
                  <Button
                    variant="outline"
                    className="h-12 rounded-full border-white/15 bg-white/[0.06] px-7 text-sm font-semibold text-white backdrop-blur-md hover:bg-white/[0.12] hover:border-white/25"
                  >
                    Explore catalog <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                </Link>
              </div>

              <div className="mt-9 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-white/50">
                <span className="inline-flex items-center gap-1.5">
                  <Star className="h-3.5 w-3.5 fill-amber-300 text-amber-300" /> HD streams
                </span>
                <span className="hidden h-1 w-1 rounded-full bg-white/25 sm:inline-block" />
                <span className="inline-flex items-center gap-1.5">
                  <Zap className="h-3.5 w-3.5 text-cyan-300" /> Fast player
                </span>
                <span className="hidden h-1 w-1 rounded-full bg-white/25 sm:inline-block" />
                <span className="inline-flex items-center gap-1.5">
                  <Tv className="h-3.5 w-3.5 text-fuchsia-300" /> New drops daily
                </span>
              </div>
            </div>

            {/* ---- Right: glass poster card ---- */}
            {hero && (
              <div className="relative hidden lg:block animate-fade-up">
                <Link to={`/watch/${hero.slug || hero.id}`} className="group block">
                  {/* halo */}
                  <div className="absolute -inset-4 rounded-[32px] bg-gradient-to-br from-violet-500/35 via-fuchsia-500/20 to-transparent blur-2xl opacity-70 group-hover:opacity-100 transition-opacity duration-500" />

                  <div className="relative rotate-[1.5deg] group-hover:rotate-0 transition-transform duration-500 ease-out">
                    <div className="relative overflow-hidden rounded-3xl border border-white/12 shadow-2xl shadow-violet-950/60">
                      <img
                        src={hero.thumbnail || posterFallback}
                        alt={hero.title}
                        className="aspect-[4/5] w-full object-cover transition-transform duration-700 group-hover:scale-[1.06]"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-black/25" />

                      {/* play button */}
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="flex h-16 w-16 items-center justify-center rounded-full border border-white/30 bg-white/15 shadow-2xl backdrop-blur-md transition-all duration-300 group-hover:scale-110 group-hover:border-violet-300/60 group-hover:bg-violet-500/45">
                          <Play className="h-6 w-6 translate-x-0.5 fill-white text-white" />
                        </span>
                      </div>

                      {/* card footer */}
                      <div className="absolute inset-x-0 bottom-0 p-5">
                        <div className="mb-2 flex flex-wrap items-center gap-1.5">
                          <span className="rounded-md bg-violet-500/80 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white">
                            {hero.category}
                          </span>
                          {hero.durationFormatted && (
                            <span className="rounded-md bg-black/55 px-2 py-0.5 text-[10px] font-semibold text-white/85 backdrop-blur-sm">
                              {hero.durationFormatted}
                            </span>
                          )}
                        </div>
                        <p className="font-display text-lg font-bold leading-tight text-white line-clamp-2">
                          {hero.title}
                        </p>
                      </div>
                    </div>
                  </div>
                </Link>
              </div>
            )}
          </div>
        </div>

        {/* Bottom fade into page background */}
        <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-background to-transparent" />
      </section>

      <AdSlot position="native_banner" />

      {/* ===== Genre Tiles ===== */}
      {categories.length > 0 && (
        <section className="mb-12 mt-12">
          <div className="mb-5 flex items-end justify-between gap-4">
            <div>
              <p className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.22em] text-violet-300/80">
                <LayoutGrid className="h-3.5 w-3.5" /> Browse the vibe
              </p>
              <h2 className="mt-1.5 font-display text-2xl font-extrabold tracking-tight text-white">
                Genres for every mood
              </h2>
            </div>
            <Link
              to="/browse?view=categories"
              className="inline-flex items-center gap-1 text-xs font-bold text-violet-300 hover:text-violet-200 transition-colors"
            >
              All genres <ChevronRight className="h-3.5 w-3.5" />
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {categories.map((cat) => (
              <Link
                key={cat.id}
                to={`/browse?category=${cat.slug}`}
                className="group relative overflow-hidden rounded-2xl border border-white/[0.07] p-4 transition-all duration-300 hover:-translate-y-1 hover:border-violet-400/40 hover:shadow-lg hover:shadow-violet-950/40"
                style={{ background: `linear-gradient(135deg, ${cat.color}17, rgba(255,255,255,0.02) 65%)` }}
              >
                <div
                  className="absolute -right-6 -top-6 h-16 w-16 rounded-full opacity-0 blur-2xl transition-opacity duration-300 group-hover:opacity-100"
                  style={{ backgroundColor: cat.color }}
                />
                <span
                  className="relative flex h-9 w-9 items-center justify-center rounded-xl ring-1 ring-inset transition-transform duration-300 group-hover:scale-110"
                  style={{
                    backgroundColor: `${cat.color}1f`,
                    color: cat.color,
                    boxShadow: `inset 0 0 0 1px ${cat.color}33`,
                  }}
                >
                  <CategoryIcon name={cat.icon} className="h-4 w-4" />
                </span>
                <div className="relative mt-5 text-[13px] font-bold leading-tight text-white group-hover:text-violet-200 transition-colors">
                  {cat.name}
                </div>
                <div className="relative mt-1.5 inline-flex items-center gap-1 text-[11px] font-medium text-white/40 group-hover:text-violet-300/80 transition-colors">
                  Explore now <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" />
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* ===== Rails ===== */}
      <Rail
        title="Trending now"
        kicker="Most watched this week"
        icon={<Flame className="h-4 w-4 text-orange-300" />}
        videos={trending}
      />
      <AdSlot position="related_between" />
      {anime.length > 0 && (
        <Rail
          title="Anime spotlight"
          kicker="Fan-favorite worlds"
          icon={<Sparkles className="h-4 w-4 text-fuchsia-300" />}
          videos={anime}
        />
      )}
      {movies.length > 0 && (
        <Rail
          title="Movie night"
          kicker="Big screen energy"
          icon={<Tv className="h-4 w-4 text-cyan-300" />}
          videos={movies}
        />
      )}
      <Rail
        title="Fresh releases"
        kicker="Just added to the catalog"
        icon={<Zap className="h-4 w-4 text-amber-300" />}
        videos={latest}
      />
    </MainLayout>
  );
};
