import { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { AdSlot } from '@/components/ads/AdSlot';
import { storageService } from '@/services/storageService';
import type { VideoItem } from '@/types/video';
import { Play } from 'lucide-react';

const PASS_TTL_MS = 30 * 60 * 1000;
const passKey = (videoId: string) => `cm_wait_passed:${videoId}`;

/** Has this visitor already waited for this video (within the last 30 minutes)? */
export function hasPassedWait(videoId: string): boolean {
  try {
    const t = Number(sessionStorage.getItem(passKey(videoId)) || 0);
    return Date.now() - t < PASS_TTL_MS;
  } catch {
    return false;
  }
}

function markPassed(videoId: string): void {
  try {
    sessionStorage.setItem(passKey(videoId), String(Date.now()));
  } catch {
    /* ignore */
  }
}

/** Optional intermediate page: "Please wait N seconds..." with ads, then the video page. */
export const WaitPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [video, setVideo] = useState<VideoItem | null>(null);
  const settings = storageService.getSettings();
  const total = useRef(Math.max(1, Math.round(Number(settings.intermediateWaitSeconds) || 5))).current;
  const [left, setLeft] = useState(total);

  useEffect(() => {
    const found = id ? storageService.getVideoById(id) : undefined;
    if (!found) {
      navigate('/', { replace: true });
      return;
    }
    if (!settings.showIntermediatePage) {
      markPassed(found.id);
      navigate(`/watch/${id}`, { replace: true });
      return;
    }
    setVideo(found);
    window.scrollTo({ top: 0 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, navigate]);

  // count down only while the tab is visible, so the ads on this page are really seen
  useEffect(() => {
    if (!video) return;
    const timer = window.setInterval(() => {
      if (!document.hidden) setLeft((n) => Math.max(0, n - 1));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [video]);

  const proceed = () => {
    if (!video || left > 0) return;
    markPassed(video.id);
    navigate(`/watch/${id}`, { replace: true });
  };

  const pct = Math.round(((total - left) / total) * 100);

  return (
    <MainLayout>
      <AdSlot position="above_player" />
      <div className="relative mx-auto max-w-2xl overflow-hidden rounded-3xl border border-white/[0.08] bg-card/60 backdrop-blur-md p-6 sm:p-8 text-center my-4">
        <div className="absolute -top-20 left-1/2 -translate-x-1/2 h-44 w-80 rounded-full bg-violet-600/15 blur-[80px] pointer-events-none" />
        {video?.thumbnail && (
          <div className="relative mb-5 overflow-hidden rounded-2xl ring-1 ring-white/[0.08]">
            <img
              src={video.thumbnail}
              alt=""
              className="w-full aspect-video object-cover opacity-75"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
          </div>
        )}
        <h1 className="relative font-display text-lg sm:text-xl font-extrabold text-white mb-6 leading-snug line-clamp-2">
          {video?.title || 'Loading…'}
        </h1>
        <div
          className="relative mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-full"
          style={{ background: `conic-gradient(#a855f7 ${pct}%, rgba(255,255,255,.08) 0)` }}
          aria-hidden="true"
        >
          <span className="absolute inset-[7px] rounded-full bg-[#0d0d1c] flex items-center justify-center">
            <span className="font-display text-3xl font-black text-white">{left}</span>
          </span>
        </div>
        <p className="relative text-[15px] font-bold text-white" aria-live="polite">
          {left > 0 ? `Please wait ${left} second${left === 1 ? '' : 's'}…` : 'Your video is ready!'}
        </p>
        <p className="relative text-xs text-muted-foreground mt-2 mb-6">
          We are preparing your stream. Please keep this tab open.
        </p>
        <button
          type="button"
          className="relative inline-flex items-center gap-2 h-12 px-8 rounded-full text-sm font-bold text-white bg-gradient-to-r from-violet-600 to-fuchsia-500 shadow-[0_8px_30px_rgba(168,85,247,0.35)] hover:brightness-110 disabled:opacity-45 disabled:shadow-none disabled:cursor-not-allowed transition-all"
          disabled={left > 0}
          onClick={proceed}
        >
          <Play className="h-4 w-4 fill-current" />
          {left > 0 ? 'Please wait…' : 'Continue to video'}
        </button>
      </div>
      <AdSlot position="native_banner" />
      <AdSlot position="below_player" />
      <AdSlot position="related_between" />
    </MainLayout>
  );
};
